import sys
import asyncio
import random

# Fix lỗi asyncio trên Windows (nếu có)
if sys.platform.startswith("win"):
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from ui.app_window import AppWindow

def generate_cube_graph(app):
    """
    Hàm tạo hình lập phương với tọa độ giả lập 3D
    """
    g = app.graph_area
    g.clear_all() # Xóa sạch cũ
    
    # 1. Định nghĩa tọa độ để tạo hiệu ứng 3D (Cabinet Projection)
    # Lấy tâm màn hình vẽ (ước lượng)
    cx, cy = 700, 350 
    size = 120   # Kích thước cạnh
    offset = 60  # Độ lệch chiều sâu

    # Map tọa độ: (x, y)
    # Mặt trước (A, B, C, D)
    nodes_pos = {
        "A": (cx - size, cy - size),
        "B": (cx + size, cy - size),
        "C": (cx + size, cy + size),
        "D": (cx - size, cy + size),
        
        # Mặt sau (E, F, G, H) - Lệch lên trên bên phải
        "E": (cx - size + offset, cy - size - offset),
        "F": (cx + size + offset, cy - size - offset),
        "G": (cx + size + offset, cy + size - offset),
        "H": (cx - size + offset, cy + size - offset),
    }

    # 2. Thêm Node với tọa độ
    for name, (x, y) in nodes_pos.items():
        g.add_node(name, x=x, y=y)

    # 3. Thêm Cạnh (Vô hướng)
    edges = [
        # Mặt trước
        ("A", "B"), ("B", "C"), ("C", "D"), ("D", "A"),
        # Mặt sau
        ("E", "F"), ("F", "G"), ("G", "H"), ("H", "E"),
        # Nối 2 mặt
        ("A", "E"), ("B", "F"), ("C", "G"), ("D", "H")
    ]

    for u, v in edges:
        # Random trọng số từ 1 đến 20 cho sinh động
        w = random.randint(1, 20)
        # False = Vô hướng
        g.add_edge(u, v, w, False)

    # 4. Cập nhật UI
    # Set loại đồ thị thành vô hướng để logic check đúng
    if hasattr(app, 'left_panel'):
        app.left_panel.graph_directed_var.set(False) 
    
    g.graph_type = "undirected"
    g.redraw()
    app.log_panel.write("Auto-generated: Hình lập phương (Cube) với trọng số ngẫu nhiên.")

def generate_bipartite_graph(app):
    """
    Hàm tạo đồ thị 2 phía (Bipartite) - GIỮ LẠI ĐỂ DÙNG KHI CẦN
    """
    g = app.graph_area
    g.clear_all() 

    left_nodes = ["A", "B", "C", "D", "E"]
    right_nodes = ["F", "G", "H", "I", "J"]

    for i, name in enumerate(left_nodes):
        g.add_node(name, x=300, y=150 + i * 80)

    for i, name in enumerate(right_nodes):
        g.add_node(name, x=700, y=150 + i * 80)

    for u in left_nodes:
        for v in right_nodes:
            if random.random() > 0.5:
                w = random.randint(1, 20) 
                g.add_edge(u, v, w, False)

    if hasattr(app, 'left_panel'):
        app.left_panel.graph_directed_var.set(False)

    g.graph_type = "undirected"
    g.redraw()
    app.log_panel.write("Auto-generated: Đồ thị 2 phía (Bipartite).")


if __name__ == "__main__":
    app = AppWindow()
    
    # --- CHẠY HÌNH LẬP PHƯƠNG MẶC ĐỊNH ---
    app.after(100, lambda: generate_cube_graph(app))

    app.mainloop()