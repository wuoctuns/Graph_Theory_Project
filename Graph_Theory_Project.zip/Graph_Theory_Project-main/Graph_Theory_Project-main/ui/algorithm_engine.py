import heapq
import random
from datetime import datetime
from collections import deque, defaultdict
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional, Any
from core.algorithms.janus_service import JanusGraphService

# ============================================================
# Helper dataclass
# ============================================================
@dataclass
class ExplainBlock:
    title: str
    lines: List[str]

    def to_text(self) -> str:
        s = [f"== {self.title} =="]
        s.extend(self.lines)
        return "\n".join(s)

class AlgorithmEngine:
    def __init__(self, graph_area, log_panel, result_panel):
        """
        FIX: Nhận đúng 3 parameters như được gọi từ app_window.py
        """
        self.graph_area = graph_area
        self.log_panel = log_panel
        self.result_panel = result_panel
        self.g = graph_area  # Alias để tương thích code cũ
        
        # Animation control
        self._animation_ids = []  # Track animation callbacks
        
        # Mock JanusGraph service
        self.janus_service = JanusGraphService()
        self._janus_connected = False

    # ============================================================
    # HELPER CƠ BẢN
    # ============================================================
    def _log(self, msg: str):
        if self.log_panel:
            self.log_panel.write(msg)

    def _emit(self, r: Dict[str, Any]) -> Dict[str, Any]:
        if self.result_panel:
            self.result_panel.show(r)
        return r

    def _fail(self, algorithm: str, reason: str, theory: str, engine: str = "Python", **data) -> Dict[str, Any]:
        return self._emit({
            "algorithm": algorithm, "engine": engine, "success": False,
            "reason": reason, "theory": theory, **data
        })

    def _success(self, algorithm: str, engine: str = "Python", **data) -> Dict[str, Any]:
        return self._emit({
            "algorithm": algorithm, "engine": engine, "success": True, **data
        })

    # ============================================================
    # HELPER QUAN TRỌNG: PHÂN BIỆT RÕ RÀNG 2 CHẾ ĐỘ
    # ============================================================
    def _get_neighbors_respect_mode(self, u):
        """
        Lấy hàng xóm TUÂN THỦ chặt chẽ chế độ có hướng/vô hướng.
        Hàm này dùng cho BFS, DFS, Dijkstra, Bellman-Ford, Hamilton.
        """
        return self.g.get_neighbors(u)

    def _get_neighbors_ignore_direction(self, u):
        """
        Lấy hàng xóm BẤT KỂ chiều mũi tên.
        Hàm này CHỈ DÙNG CHO: Tô màu đồ thị (Coloring), MST, Euler (Undirected view).
        """
        neighbors = []
        seen = set()  # FIX: Tránh duplicate trong multigraph
        
        for x, y, w, d in self.g.edges:
            if x == u and y not in seen:
                neighbors.append((y, w))
                seen.add(y)
            elif y == u and x not in seen:
                neighbors.append((x, w))
                seen.add(x)
        return neighbors

    # ============================================================
    # ANIMATION - FIX: Add cancel và animate_path
    # ============================================================
    def _cancel_animations(self):
        """Cancel all pending animations"""
        for aid in self._animation_ids:
            try:
                self.g.master.after_cancel(aid)
            except:
                pass
        self._animation_ids.clear()

    def animate_edges(self, edges: List[Tuple[str, str]], delay: int = 300):
        """Animate edges one by one"""
        if not edges:
            return
        
        self._cancel_animations()
        self.g.clear_highlight()
        
        def step(i):
            if i >= len(edges):
                return
            u, v = edges[i]
            self.g.highlight_edge(u, v, "#EF4444")
            aid = self.g.master.after(delay, lambda: step(i + 1))
            self._animation_ids.append(aid)
        
        step(0)

    def animate_path(self, path: List[str], delay: int = 300):
        """
        FIX: Thêm method này - được gọi từ left_panel.py
        Animate a path (list of vertices)
        """
        if not path or len(path) < 2:
            return
        
        edges = list(zip(path[:-1], path[1:]))
        self.animate_edges(edges, delay)

    def animate_mst(self, edges: List[Tuple[str, str, int]], delay: int = 300):
        """Animate MST edges"""
        if not edges:
            return
        
        self._cancel_animations()
        self.g.clear_highlight()
        
        for u, v, _ in edges:
            self.g.highlight_edge(u, v, "#10B981")

    # ============================================================
    # 1. BFS (TUÂN THỦ HƯỚNG)
    # ============================================================
    def bfs(self, start: str):
        if start not in self.g.nodes:
            return self._fail("BFS", "Đỉnh không tồn tại", "")

        visited, queue = [], deque([start])
        seen = {start}

        while queue:
            u = queue.popleft()
            visited.append(u)
            
            neighbors = sorted(self._get_neighbors_respect_mode(u), key=lambda x: x[0])
            for v, w in neighbors:
                if v not in seen:
                    seen.add(v)
                    queue.append(v)

        explain = ExplainBlock("BFS Theory", [
            "BFS (Breadth-First Search) duyệt theo lớp.",
            f"Loại đồ thị: {'CÓ HƯỚNG' if self.g.graph_type == 'directed' else 'VÔ HƯỚNG'}",
            "Lưu ý: Nếu đồ thị CÓ HƯỚNG, thuật toán chỉ đi theo chiều mũi tên.",
            f"Thứ tự: {' -> '.join(visited)}"
        ]).to_text()
        
        return self._success("BFS", start=start, order=visited, theory=explain)

    # ============================================================
    # 2. DFS (TUÂN THỦ HƯỚNG)
    # ============================================================
    def dfs(self, start: str):
        if start not in self.g.nodes:
            return self._fail("DFS", "Đỉnh không tồn tại", "")

        visited, stack = [], [start]
        seen = set()

        while stack:
            u = stack.pop()
            if u in seen:
                continue
            seen.add(u)
            visited.append(u)
            
            neighbors = sorted(self._get_neighbors_respect_mode(u), key=lambda x: x[0], reverse=True)
            for v, w in neighbors:
                if v not in seen:
                    stack.append(v)

        explain = ExplainBlock("DFS Theory", [
            "DFS (Depth-First Search) duyệt theo chiều sâu.",
            f"Loại đồ thị: {'CÓ HƯỚNG' if self.g.graph_type == 'directed' else 'VÔ HƯỚNG'}",
            "Lưu ý: Nếu đồ thị CÓ HƯỚNG, thuật toán chỉ đi theo chiều mũi tên.",
            f"Thứ tự: {' -> '.join(visited)}"
        ]).to_text()
        
        return self._success("DFS", start=start, order=visited, theory=explain)

    # ============================================================
    # 3. DIJKSTRA (TUÂN THỦ HƯỚNG)
    # ============================================================
    def dijkstra(self, start: str, end: str):
        if start not in self.g.nodes or end not in self.g.nodes:
            return self._fail("Dijkstra", "Đỉnh không tồn tại", "")
        
        if any(w < 0 for _, _, w, _ in self.g.edges):
            return self._fail("Dijkstra", "Trọng số âm", "Hãy dùng Bellman-Ford cho đồ thị có trọng số âm.")

        dist = {n: float('inf') for n in self.g.nodes}
        parent = {n: None for n in self.g.nodes}
        dist[start] = 0
        pq = [(0, start)]
        visited = set()

        while pq:
            d, u = heapq.heappop(pq)
            
            if u in visited:
                continue
            
            visited.add(u)
            
            if u == end:
                break

            for v, w in self._get_neighbors_respect_mode(u):
                if v not in visited and dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w
                    parent[v] = u
                    heapq.heappush(pq, (dist[v], v))

        if dist[end] == float('inf'):
            return self._fail("Dijkstra", "Không có đường đi", 
                            f"Không thể đi từ {start} đến {end} theo chiều mũi tên." if self.g.graph_type == 'directed' else f"Không có đường đi giữa {start} và {end}.")

        # Reconstruct path
        path = []
        curr = end
        while curr:
            path.append(curr)
            curr = parent[curr]
        path.reverse()

        edges = list(zip(path[:-1], path[1:]))
        self.animate_edges(edges)
        
        theory = f"Chi phí nhỏ nhất: {dist[end]}\nSố cạnh: {len(edges)}"
        return self._success("Dijkstra", path=path, cost=dist[end], edges_count=len(edges), theory=theory)

    # ============================================================
    # 4. BELLMAN-FORD (TUÂN THỦ HƯỚNG & VÔ HƯỚNG)
    # ============================================================
    def bellman_ford(self, start: str, end: str):
        if start not in self.g.nodes or end not in self.g.nodes:
            return self._fail("Bellman-Ford", "Đỉnh không tồn tại", "")

        dist = {n: float('inf') for n in self.g.nodes}
        parent = {n: None for n in self.g.nodes}
        dist[start] = 0

        # Build edge list based on graph type
        edge_list = []
        for u, v, w, d in self.g.edges:
            edge_list.append((u, v, w))
            # If undirected, add reverse edge
            if not d:
                edge_list.append((v, u, w))

        # Relax V-1 times
        for _ in range(len(self.g.nodes) - 1):
            updated = False
            for u, v, w in edge_list:
                if dist[u] != float('inf') and dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w
                    parent[v] = u
                    updated = True
            
            if not updated:
                break

        # Check negative cycle
        for u, v, w in edge_list:
            if dist[u] != float('inf') and dist[u] + w < dist[v]:
                return self._fail("Bellman-Ford", "Chu trình âm", 
                                "Đồ thị chứa chu trình có tổng trọng số âm. Không thể tìm đường đi ngắn nhất.")

        if dist[end] == float('inf'):
            return self._fail("Bellman-Ford", "Không có đường đi", 
                            f"Không thể đi từ {start} đến {end}.")

        # Reconstruct path
        path = []
        curr = end
        while curr:
            path.append(curr)
            curr = parent[curr]
        path.reverse()
        
        edges = list(zip(path[:-1], path[1:]))
        self.animate_edges(edges)
        
        theory = f"Chi phí nhỏ nhất: {dist[end]}\nSố cạnh: {len(edges)}\n\nBellman-Ford có thể xử lý trọng số âm."
        return self._success("Bellman-Ford", path=path, cost=dist[end], edges_count=len(edges), theory=theory)

    # ============================================================
    # 5. PRIM (MST) 
    # ============================================================
    def prim(self, start: str = None):
        if not self.g.nodes:
            return self._fail("Prim", "Đồ thị rỗng", "")
        
        if start is None or start not in self.g.nodes:
            start = next(iter(self.g.nodes))
        
        mst_edges = []
        visited = {start}
        pq = []
        
        # Add edges from start
        for v, w in self._get_neighbors_ignore_direction(start):
            heapq.heappush(pq, (w, start, v))

        total_w = 0
        
        while pq and len(visited) < len(self.g.nodes):
            w, u, v = heapq.heappop(pq)
            
            if v in visited:
                continue
            
            visited.add(v)
            mst_edges.append((u, v, w))
            total_w += w
            
            # Add edges from v
            for next_v, next_w in self._get_neighbors_ignore_direction(v):
                if next_v not in visited:
                    heapq.heappush(pq, (next_w, v, next_v))

        if len(visited) < len(self.g.nodes):
            return self._fail("Prim", "Đồ thị không liên thông", 
                            f"Chỉ tìm được {len(visited)}/{len(self.g.nodes)} đỉnh. Đồ thị không liên thông.")

        self.animate_mst(mst_edges)
        
        theory = f"Tổng trọng số MST: {total_w}\nSố cạnh: {len(mst_edges)}\n\nPrim's algorithm tìm cây khung nhỏ nhất."
        return self._success("Prim", edges=mst_edges, cost=total_w, theory=theory)

    # ============================================================
    # 6. KRUSKAL (MST) 
    # ============================================================
    def kruskal(self):
        if not self.g.nodes:
            return self._fail("Kruskal", "Đồ thị rỗng", "")
        
        # Disjoint Set (Union-Find)
        parent = {n: n for n in self.g.nodes}
        
        def find(n):
            if parent[n] != n:
                parent[n] = find(parent[n])
            return parent[n]
        
        def union(n1, n2):
            r1, r2 = find(n1), find(n2)
            if r1 != r2:
                parent[r1] = r2
                return True
            return False
        
        # Build edge list (remove duplicates for undirected)
        edge_set = set()
        for u, v, w, d in self.g.edges:
            # Normalize edge for undirected
            if u <= v:
                edge_set.add((w, u, v))
            else:
                edge_set.add((w, v, u))
        
        edges_sorted = sorted(list(edge_set))
        
        mst_edges = []
        total_w = 0
        
        for w, u, v in edges_sorted:
            if union(u, v):
                mst_edges.append((u, v, w))
                total_w += w
        
        if len(mst_edges) < len(self.g.nodes) - 1 and len(self.g.nodes) > 1:
            return self._fail("Kruskal", "Đồ thị không liên thông", 
                            f"Chỉ tìm được {len(mst_edges)} cạnh, cần {len(self.g.nodes)-1} cạnh.")

        self.animate_mst(mst_edges)
        
        theory = f"Tổng trọng số MST: {total_w}\nSố cạnh: {len(mst_edges)}\n\nKruskal's algorithm sắp xếp cạnh theo trọng số."
        return self._success("Kruskal", edges=mst_edges, cost=total_w, theory=theory)

    # ============================================================
    # 7. EULER 
    # ============================================================
    def euler_path(self):
        """Find Euler path/trail in undirected view"""
        if not self.g.nodes or not self.g.edges:
            return self._fail("Euler", "Đồ thị rỗng", "")
        
        # Calculate degree (undirected view)
        deg = {n: 0 for n in self.g.nodes}
        for u, v, _, _ in self.g.edges:
            deg[u] += 1
            deg[v] += 1
        
        odd = [v for v in deg if deg[v] % 2 != 0]
        
        if len(odd) not in [0, 2]:
            return self._fail("Euler", "Không thỏa mãn điều kiện", 
                            f"Số đỉnh bậc lẻ là {len(odd)}. Cần 0 (chu trình Euler) hoặc 2 (đường đi Euler).")
        
        # Find start vertex
        start = odd[0] if len(odd) == 2 else next(iter(self.g.nodes))
        
        # Build adjacency list (undirected, with edge removal)
        adj = defaultdict(list)
        for u, v, w, _ in self.g.edges:
            adj[u].append(v)
            adj[v].append(u)
        
        # Hierholzer's algorithm
        stack = [start]
        path = []
        
        while stack:
            u = stack[-1]
            if adj[u]:
                v = adj[u].pop()
                # Remove reverse edge
                if u in adj[v]:
                    adj[v].remove(u)
                stack.append(v)
            else:
                path.append(stack.pop())
        
        path.reverse()
        
        # Verify we used all edges
        if len(path) - 1 != len(self.g.edges):
            return self._fail("Euler", "Đồ thị không liên thông", 
                            f"Chỉ đi qua {len(path)-1}/{len(self.g.edges)} cạnh. Đồ thị không liên thông.")
        
        edges_vis = list(zip(path[:-1], path[1:]))
        self.animate_edges(edges_vis)
        
        path_type = "Chu trình Euler" if len(odd) == 0 else "Đường đi Euler"
        theory = f"{path_type}\nĐường đi: {' -> '.join(path)}\nSố cạnh: {len(edges_vis)}"
        return self._success("Euler", path=path, theory=theory)

    def euler_cycle(self):
        """Find Euler cycle (all vertices must have even degree)"""
        if not self.g.nodes or not self.g.edges:
            return self._fail("Euler Cycle", "Đồ thị rỗng", "")
        
        # Calculate degree
        deg = {n: 0 for n in self.g.nodes}
        for u, v, _, _ in self.g.edges:
            deg[u] += 1
            deg[v] += 1
        
        odd = [v for v in deg if deg[v] % 2 != 0]
        
        if odd:
            return self._fail("Euler Cycle", "Không có chu trình Euler", 
                            f"Tồn tại {len(odd)} đỉnh bậc lẻ. Chu trình Euler yêu cầu tất cả đỉnh có bậc chẵn.")
        
        return self.euler_path()

    # ============================================================
    # 8. HAMILTON (TUÂN THỦ HƯỚNG)
    # ============================================================
    def hamilton(self, mode="path"):
        if not self.g.nodes:
            return self._fail("Hamilton", "Đồ thị rỗng", "")
        
        if len(self.g.nodes) == 1:
            if mode == "cycle":
                return self._fail("Hamilton Cycle", "Không đủ đỉnh", "Cần ít nhất 3 đỉnh cho chu trình Hamilton.")
            else:
                path = [next(iter(self.g.nodes))]
                return self._success("Hamilton", path=path, theory=f"Hamilton path: {path[0]}")
        
        start = next(iter(self.g.nodes))
        n = len(self.g.nodes)
        path = [start]
        used = {start}
        
        def backtrack():
            if len(path) == n:
                if mode == "cycle":
                    last = path[-1]
                    # Check if there's an edge from last to start
                    for v, _ in self._get_neighbors_respect_mode(last):
                        if v == start:
                            return True
                    return False
                return True
            
            u = path[-1]
            neighbors = [v for v, _ in self._get_neighbors_respect_mode(u)]
            
            for v in neighbors:
                if v not in used:
                    used.add(v)
                    path.append(v)
                    if backtrack():
                        return True
                    path.pop()
                    used.remove(v)
            
            return False
        
        if backtrack():
            if mode == "cycle":
                path.append(path[0])
            
            edges = list(zip(path[:-1], path[1:]))
            self.animate_edges(edges)
            
            theory = f"Hamilton {mode}\nĐường đi: {' -> '.join(path)}\nSố đỉnh: {n}\nSố cạnh: {len(edges)}"
            return self._success("Hamilton", path=path, theory=theory)
        else:
            return self._fail("Hamilton", "Không tìm thấy", 
                            f"Không tồn tại {'chu trình' if mode == 'cycle' else 'đường đi'} Hamilton trong đồ thị này.")

    # ============================================================
    # 9. GRAPH COLORING
    # ============================================================
    def color_graph(self):
        """
        Graph Coloring với xử lý đúng cho cả directed và undirected.
        
        QUY TẮC:
        - UNDIRECTED: Hai đỉnh kề nhau (u-v) không được cùng màu
        - DIRECTED: Hai đỉnh có cạnh nối (u→v hoặc v→u) không được cùng màu
        
        Trong cả 2 trường hợp, ta xem xét "conflict graph" để tô màu.
        """
        if not self.g.nodes:
            return self._fail("Graph Coloring", "Đồ thị rỗng", "")
        
        # Build conflict graph (undirected view for coloring)
        # Hai đỉnh conflict nếu có cạnh nối giữa chúng (bất kể hướng)
        conflict_adj = defaultdict(set)
        
        for u, v, _, _ in self.g.edges:
            if u != v:  # Ignore self-loops
                conflict_adj[u].add(v)
                conflict_adj[v].add(u)
        
        # Sort vertices by degree (Welsh-Powell heuristic)
        nodes = sorted(self.g.nodes, key=lambda u: len(conflict_adj[u]), reverse=True)
        
        # Color palette (dynamic generation)
        base_palette = [
            ("#FF1900", "Red"),
            ("#259CEA", "Blue"), 
            ("#00FF6A", "Green"),
            ("#FCCA00", "Yellow"),
            ("#B100F7", "Purple"),
            ("#FF7700", "Orange"),
            ("#1ABC9C", "Cyan"),
            ("#FF69B4", "Pink"),
            ("#8B4513", "Brown"),
            ("#808080", "Gray"),
        ]
        
        # Generate more colors if needed
        def generate_color(index):
            if index < len(base_palette):
                return base_palette[index]
            # Generate random color for extra colors
            import random
            random.seed(index)
            hex_code = "#{:06x}".format(random.randint(0, 0xFFFFFF))
            return (hex_code, f"Color{index+1}")
        
        color_map = {}
        result_details = []
        
        for u in nodes:
            # Get colors of neighbors
            neighbor_colors = set()
            for v in conflict_adj[u]:
                if v in color_map:
                    neighbor_colors.add(color_map[v])
            
            # Find smallest available color
            color_index = 0
            while color_index in neighbor_colors:
                color_index += 1
            
            # Assign color
            hex_code, name = generate_color(color_index)
            color_map[u] = color_index
            
            # Set visual color
            self.g.set_node_color(u, hex_code)
            result_details.append(f"- {u}: {name} ({hex_code})")
        
        num_colors = len(set(color_map.values()))
        
        theory_text = (
            f"Số màu sử dụng: {num_colors}\n"
            f"Loại đồ thị: {'CÓ HƯỚNG' if self.g.graph_type == 'directed' else 'VÔ HƯỚNG'}\n\n"
            f"Quy tắc: Hai đỉnh có cạnh nối (bất kể hướng) không được cùng màu.\n\n"
            f"Chi tiết:\n" + "\n".join(sorted(result_details))
        )
        
        return self._success("Graph Coloring", theory=theory_text)

    # ============================================================
    # JANUSGRAPH 
    # ============================================================
    def connect_janusgraph(self):
        try:
            self.janus_service.connect()
            self._janus_connected = True
            self._log("[JANUSGRAPH] Kết nối thành công...")
        except Exception as e:
            self._log(f"[JANUSGRAPH][ERROR] {e}")


    from datetime import datetime

    def upload_graph_to_janusgraph(self, meta):
        if not self._janus_connected:
            self._log("[JANUSGRAPH] Chưa kết nối JanusGraph.")
            return False

        graph_id = meta.get("graph_id")
        graph_name = meta.get("name", "N/A")

        try:
            # Loại đồ thị
            directed = any(d for (_, _, _, d) in self.g.edges)

            # Thời gian lưu
            from datetime import datetime
            saved_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            meta["directed"] = directed
            meta["saved_at"] = saved_at

            # ===== UPLOAD THẬT =====
            self.janus_service.upload_graph(self.g, meta)

            # ===== ĐẾM =====
            v_count = self.janus_service.client.submit(
                "g.V().has('graph_id', gid).count()",
                {"gid": graph_id}
            ).all().result()[0]

            e_count = self.janus_service.client.submit(
                "g.E().has('graph_id', gid).count()",
                {"gid": graph_id}
            ).all().result()[0]

            self._log(
                "[JANUSGRAPH][UPLOAD THÀNH CÔNG]\n"
                f"  • Tên đồ thị : {graph_name}\n"
                f"  • ID đồ thị  : {graph_id}\n"
                f"  • Loại       : {'Có hướng' if directed else 'Vô hướng'}\n"
                f"  • Số đỉnh    : {v_count}\n"
                f"  • Số cạnh    : {e_count}\n"
                f"  • Thời gian  : {saved_at}"
            )

            return True

        except Exception as e:
            # rollback
            try:
                self.janus_service.delete_graph(graph_id)
            except Exception:
                pass

            self._log(
                "[JANUSGRAPH][ERROR] Upload thất bại\n"
                f"  • Tên đồ thị : {graph_name}\n"
                f"  • ID đồ thị  : {graph_id}\n"
                f"  • Lỗi        : {e}"
            )
            return False

    def get_janus_graph_list(self):
        if not self._janus_connected:
            return []

        try:
            result = self.janus_service.client.submit("""
                g.V().hasLabel('graph_meta')
                .project(
                    'graph_id',
                    'name',
                    'description',
                    'directed',
                    'node_count',
                    'edge_count',
                    'saved_at'
                )
                .by('graph_id')
                .by('name')
                .by('description')
                .by('directed')
                .by('node_count')
                .by('edge_count')
                .by('saved_at')
            """).all().result()

            graphs = []

            for g in result:
                saved_at_raw = g.get("saved_at")

                if isinstance(saved_at_raw, str):
                    saved_at_str = saved_at_raw
                else:
                    saved_at_str = "N/A"

                graphs.append({
                    "graph_id": g.get("graph_id", ""),
                    "name": g.get("name", ""),
                    "description": g.get("description", ""),
                    "directed": bool(g.get("directed", False)),
                    "node_count": int(g.get("node_count", 0)),
                    "edge_count": int(g.get("edge_count", 0)),
                    "saved_at_str": saved_at_str
                })

            return graphs

        except Exception as e:
            self._log(f"[JANUSGRAPH][ERROR] Không lấy được danh sách đồ thị: {e}")
            return []


    def load_graph_from_janusgraph(self, graph_id):
        if not self._janus_connected:
            self._log("[JANUSGRAPH] Chưa kết nối JanusGraph.")
            return False

        try:
            # ===== LẤY META =====
            meta_rs = self.janus_service.client.submit("""
                g.V().hasLabel('graph_meta')
                .has('graph_id', gid)
                .project(
                    'name','description','directed',
                    'node_count','edge_count','saved_at'
                )
                .by('name')
                .by('description')
                .by('directed')
                .by('node_count')
                .by('edge_count')
                .by('saved_at')
            """, {"gid": graph_id}).all().result()

            if not meta_rs:
                self._log(f"[JANUSGRAPH] Không tìm thấy meta cho ID={graph_id}")
                return False

            meta = meta_rs[0]

            # ===== LOAD NODE + EDGE =====
            nodes, edges = self.janus_service.load_graph(graph_id)

            if not nodes:
                self._log(f"[JANUSGRAPH] Đồ thị ID={graph_id} không có node")
                return False

            g = self.g  # GraphArea

            # ===== CLEAR GRAPH =====
            g.clear_all()

            # ===== ADD NODE (GIỮ ĐÚNG TỌA ĐỘ) =====
            for n in nodes:
                g.nodes[n["name"]] = {
                    "x": float(n["x"]),
                    "y": float(n["y"])
                }

            # ===== ADD EDGE =====
            for e in edges:
                g.edges.append((
                    e["u"],
                    e["v"],
                    e["w"],
                    e["directed"]
                ))

            # ===== REDRAW =====
            g.redraw()

            # ===== LOG THÀNH CÔNG =====
            self.current_graph_id = graph_id
            self._log(
                "[JANUSGRAPH][DOWNLOAD THÀNH CÔNG]\n"
                f"  • Tên đồ thị : {meta.get('name','')}\n"
                f"  • ID đồ thị  : {graph_id}\n"
                f"  • Loại       : {'Có hướng' if meta.get('directed') else 'Vô hướng'}\n"
                f"  • Số đỉnh    : {len(nodes)}\n"
                f"  • Số cạnh    : {len(edges)}\n"
                f"  • Thời gian  : {meta.get('saved_at','N/A')}"
            )

            return True

        except Exception as e:
            self._log(f"[JANUSGRAPH][ERROR] Load thất bại: {e}")
            return False


    def delete_janus_graph(self, graph_id):
        if not self._janus_connected:
            self._log("[JANUSGRAPH] Chưa kết nối JanusGraph.")
            return False

        try:
            rs = self.janus_service.client.submit(
                """
                g.V().hasLabel('graph_meta')
                .has('graph_id', gid)
                .values('name')
                """,
                {"gid": graph_id}
            ).all().result()

            graph_name = rs[0] if rs else "(Không rõ tên)"

            self.janus_service.delete_graph(graph_id)

            self._log(
                "[JANUSGRAPH][DELETE THÀNH CÔNG]\n"
                f"  • Tên đồ thị : {graph_name}\n"
                f"  • ID đồ thị  : {graph_id}"
            )

            return True

        except Exception as e:
            self._log(
                "[JANUSGRAPH][ERROR] Xóa đồ thị thất bại\n"
                f"  • ID đồ thị : {graph_id}\n"
                f"  • Lỗi       : {e}"
            )
            return False
