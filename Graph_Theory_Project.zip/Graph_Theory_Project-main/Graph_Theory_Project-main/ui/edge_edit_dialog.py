import customtkinter as ctk
from tkinter import messagebox


class EdgeEditDialog(ctk.CTkToplevel):
    def __init__(self, master, u, v, w, directed, graph_area, callback):
        super().__init__(master)

        # ===== WINDOW CONFIG =====
        self.title("EDGE INFO")
        self.geometry("400x440")
        self.resizable(False, False)
        self.configure(fg_color="#1E1E1E")

        self.attributes("-topmost", True)
        self.focus_force()
        self.grab_set()

        self.u, self.v = u, v
        self.graph_area = graph_area
        self.callback = callback

        # ===== TITLE =====
        ctk.CTkLabel(
            self,
            text="THÔNG TIN CẠNH",
            font=("Roboto", 20, "bold"),
            text_color="#E5E7EB"
        ).pack(pady=(15, 10))

        # ===== INFO =====
        self._info_row("Đỉnh đầu:", u)
        self._info_row("Đỉnh cuối:", v)
        self._info_row("Hướng:", "Có hướng" if directed else "Vô hướng")
        self._info_row("Trọng số:", str(w))

        # ===== EDIT =====
        ctk.CTkLabel(
            self,
            text="CHỈNH SỬA TRỌNG SỐ",
            text_color="#9CA3AF",
            font=("Roboto", 13)
        ).pack(pady=(15, 5))

        # ---- trọng số ----
        self.weight = ctk.CTkEntry(
            self,
            fg_color="#2A2A2A",
            border_color="#3A3A3A",
            text_color="#F9FAFB"
        )
        self.weight.insert(0, str(w))
        self.weight.pack(fill="x", padx=30, pady=(0, 10))

        # =====================================================
        # PHẦN HƯỚNG – CHỈ ÁP DỤNG NẾU CẠNH CÓ HƯỚNG
        # =====================================================
        self.directed_var = ctk.BooleanVar(value=directed)

        if directed:
            self.dir_frame = ctk.CTkFrame(self, fg_color="transparent")
            self.dir_frame.pack(pady=6, padx=30, fill="x")

            self.dir_check = ctk.CTkCheckBox(
                self.dir_frame,
                text="Cạnh có hướng",
                variable=self.directed_var,
                fg_color="#0EA5E9",
                text_color="#E5E7EB",
                command=self.toggle_direction_ui
            )
            self.dir_check.pack(anchor="w")

            # ---- chọn chiều ----
            self.dir_select_frame = ctk.CTkFrame(self, fg_color="transparent")
            self.dir_select_frame.pack(pady=6)

            self.direction = ctk.StringVar(value="u_v")

            ctk.CTkRadioButton(
                self.dir_select_frame,
                text=f"{u} → {v}",
                variable=self.direction,
                value="u_v"
            ).pack(side="left", padx=12)

            ctk.CTkRadioButton(
                self.dir_select_frame,
                text=f"{v} → {u}",
                variable=self.direction,
                value="v_u"
            ).pack(side="left", padx=12)

        # ===== BUTTON ROW =====
        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(pady=(15, 20), padx=30, fill="x")

        ctk.CTkButton(
            btn_row,
            text="LƯU",
            fg_color="#0EA5E9",
            hover_color="#0284C7",
            text_color="white",
            command=self.save
        ).pack(side="left", expand=True, fill="x", padx=(0, 8))

        ctk.CTkButton(
            btn_row,
            text="XÓA",
            fg_color="#EF4444",
            hover_color="#DC2626",
            text_color="white",
            command=self.delete
        ).pack(side="left", expand=True, fill="x", padx=(8, 0))

    # ===== INFO ROW =====
    def _info_row(self, label, value):
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=30, pady=4)

        ctk.CTkLabel(
            row,
            text=label,
            width=140,
            anchor="w",
            text_color="#9CA3AF",
            font=("Roboto", 13)
        ).pack(side="left")

        ctk.CTkLabel(
            row,
            text=value,
            anchor="w",
            text_color="#F3F4F6",
            font=("Roboto", 13, "bold")
        ).pack(side="left")

    # ===== TOGGLE DIRECTION UI =====
    def toggle_direction_ui(self):
        if self.directed_var.get():
            self.dir_select_frame.pack(pady=6)
        else:
            self.dir_select_frame.pack_forget()

    # ===== ACTIONS =====
    def save(self):
        if not self.weight.get().isdigit():
            messagebox.showerror("Lỗi", "Trọng số phải là số")
            return

        w = int(self.weight.get())
        directed = self.directed_var.get()

        u, v = self.u, self.v
        if directed and hasattr(self, "direction"):
            if self.direction.get() == "v_u":
                u, v = v, u

        self.callback("update", u, v, w, directed)
        self.destroy()

    def delete(self):
        if messagebox.askyesno("Xác nhận", "Xóa cạnh này?"):
            self.callback("delete", self.u, self.v, None, None)
            self.destroy()
