import customtkinter as ctk


class StartDialog(ctk.CTkToplevel):
    def __init__(self, master, callback):
        super().__init__(master)

        self.callback = callback

        self.title("Nhập đỉnh bắt đầu")
        self.geometry("320x160")
        self.configure(fg_color="#1E1F22")
        self.resizable(False, False)

        lbl = ctk.CTkLabel(self, text="Nhập START", font=("Roboto", 18, "bold"))
        lbl.pack(pady=10)

        self.start_entry = ctk.CTkEntry(self, placeholder_text="Đỉnh bắt đầu…")
        self.start_entry.pack(fill="x", padx=15, pady=10)

        btn = ctk.CTkButton(self, text="Chạy thuật toán", fg_color="#0EA5E9",
                            command=self.submit)
        btn.pack(fill="x", padx=15, pady=5)

        self.start_entry.bind("<Return>", lambda e: self.submit())

        self.grab_set()  # block UI

    def submit(self):
        start = self.start_entry.get().strip()
        if start == "":
            return
        self.callback(start)
        self.destroy()
