import customtkinter as ctk


class PathDialog(ctk.CTkToplevel):
    def __init__(self, master, callback):
        super().__init__(master)
        self.callback = callback

        self.title("Nhập thông tin đường đi")
        self.geometry("360x250")
        self.resizable(False, False)
        self.configure(fg_color="#1D1E20")

        # Title
        title = ctk.CTkLabel(self, text="Nhập Start và Goal",
                             font=("Roboto", 18, "bold"))
        title.pack(pady=(10, 5))

        # Start
        ctk.CTkLabel(self, text="Đỉnh bắt đầu:",
                     font=("Roboto", 14)).pack(anchor="w", padx=15)
        self.start_entry = ctk.CTkEntry(self, placeholder_text="Start…")
        self.start_entry.pack(fill="x", padx=15, pady=5)

        # Goal
        ctk.CTkLabel(self, text="Đỉnh đích:",
                     font=("Roboto", 14)).pack(anchor="w", padx=15)
        self.goal_entry = ctk.CTkEntry(self, placeholder_text="Goal…")
        self.goal_entry.pack(fill="x", padx=15, pady=5)

        # Buttons
        button = ctk.CTkButton(self, text="Chạy thuật toán",
                               fg_color="#0099FF", command=self.run)
        button.pack(fill="x", padx=15, pady=15)

        # Enter key
        self.start_entry.bind("<Return>", lambda e: self.run())
        self.goal_entry.bind("<Return>", lambda e: self.run())

        # Modal
        self.grab_set()

    def run(self):
        start = self.start_entry.get().strip()
        goal = self.goal_entry.get().strip()

        if not start or not goal:
            return

        self.callback(start, goal)
        self.destroy()
