import customtkinter as ctk
from tkinter import messagebox
import uuid


class GraphSaveDialog(ctk.CTkToplevel):
    def __init__(self, master, graph_area, callback):
        super().__init__(master)
        self.graph_area = graph_area
        self.callback = callback

        self.title("Lưu đồ thị vào JanusGraph")
        self.geometry("420x460")
        self.resizable(False, False)

        self.graph_id = str(uuid.uuid4())

        self.build_ui()
        self.grab_set()

    # ============================================================
    # UI
    # ============================================================
    def build_ui(self):
        ctk.CTkLabel(
            self,
            text="THÔNG TIN ĐỒ THỊ",
            font=("Roboto", 18, "bold")
        ).pack(pady=12)

        # ---------- tên đồ thị ----------
        self.name_entry = ctk.CTkEntry(
            self,
            placeholder_text="Tên đồ thị"
        )
        self.name_entry.pack(fill="x", padx=20, pady=8)

        # ---------- mô tả (PLACEHOLDER) ----------
        self.desc_box = ctk.CTkTextbox(self, height=90)
        self.desc_box.pack(fill="x", padx=20)

        self._set_desc_placeholder()
        self.desc_box.bind("<FocusIn>", self._clear_placeholder)
        self.desc_box.bind("<FocusOut>", self._restore_placeholder)

        # ---------- thông tin tự động ----------
        node_count = len(self.graph_area.nodes)
        edge_count = len(self.graph_area.edges)
        directed = any(d for (_, _, _, d) in self.graph_area.edges)

        info = (
            f"Số đỉnh: {node_count}\n"
            f"Số cạnh: {edge_count}\n"
            f"Loại đồ thị: {'Có hướng' if directed else 'Vô hướng'}\n"
            f"Graph ID: {self.graph_id}"
        )

        info_box = ctk.CTkTextbox(self, height=110)
        info_box.pack(fill="x", padx=20, pady=12)
        info_box.insert("1.0", info)
        info_box.configure(state="disabled")

        # ---------- button ----------
        ctk.CTkButton(
            self,
            text="LƯU & GỬI LÊN JANUSGRAPH",
            fg_color="#22C55E",
            command=self.on_save
        ).pack(pady=12)

    # ============================================================
    # PLACEHOLDER LOGIC
    # ============================================================
    def _set_desc_placeholder(self):
        self.desc_box.insert("1.0", "Mô tả đồ thị...")
        self.desc_box.configure(text_color="#6B7280")
        self._placeholder = True

    def _clear_placeholder(self, event=None):
        if getattr(self, "_placeholder", False):
            self.desc_box.delete("1.0", "end")
            self.desc_box.configure(text_color="white")
            self._placeholder = False

    def _restore_placeholder(self, event=None):
        if not self.desc_box.get("1.0", "end").strip():
            self._set_desc_placeholder()

    # ============================================================
    # SAVE
    # ============================================================
    def on_save(self):
        name = self.name_entry.get().strip()
        desc = self.desc_box.get("1.0", "end").strip()

        if not name:
            messagebox.showerror("Lỗi", "Tên đồ thị không được rỗng.")
            return

        if desc == "Mô tả đồ thị...":
            desc = ""

        meta = {
            "graph_id": self.graph_id,
            "name": name,
            "description": desc
        }

        self.callback(meta)
        self.destroy()
