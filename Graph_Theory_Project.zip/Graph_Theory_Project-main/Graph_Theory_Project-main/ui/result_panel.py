import customtkinter as ctk


class ResultPanel(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color="#0F1115")

        title = ctk.CTkLabel(
            self,
            text="KẾT QUẢ THUẬT TOÁN",
            font=("Roboto", 17, "bold")
        )
        title.pack(pady=(10, 5))

        self.text = ctk.CTkTextbox(
            self,
            wrap="word",
            font=("Consolas", 15)
        )
        self.text.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    # ============================================================
    # SHOW RESULT
    # ============================================================

    def show(self, r):
        self.text.delete("1.0", "end")

        algo = r.get("algorithm", "N/A")
        engine = r.get("engine", "Python")

        self.text.insert("end", f"Thuật toán: {algo}\n")
        self.text.insert("end", f"Engine: {engine}\n")

        # FAIL
        if not r.get("success", False):
            self.text.insert("end", "KẾT QUẢ: THẤT BẠI\n\n")
            self.text.insert("end", f"Lý do:\n{r.get('reason', '')}\n\n")
            self.text.insert("end", f"Giải thích / Định lý liên quan:\n{r.get('theory','')}\n")

            if "degree_report" in r:
                self.text.insert("end", "\n\n" + r["degree_report"])
            return

        # SUCCESS
        if "start" in r and r.get("start") is not None:
            self.text.insert("end", f"Start: {r.get('start')}\n")
        if "end" in r and r.get("end") is not None:
            self.text.insert("end", f"End  : {r.get('end')}\n")

        self.text.insert("end", "\n")

        # BFS / DFS
        if "order" in r:
            self.text.insert("end", "Thứ tự duyệt:\n")
            self.text.insert("end", " → ".join(r["order"]) + "\n")
            if "edges_count" in r:
                self.text.insert("end", f"\nSố cạnh (ước lượng theo thứ tự duyệt): {r['edges_count']}\n")

        # PATH
        if "path" in r:
            self.text.insert("end", "Đường đi:\n")
            self.text.insert("end", " → ".join(r["path"]) + "\n\n")
            self.text.insert("end", f"Số cạnh: {r.get('edges_count')}\n")
            self.text.insert("end", f"Chi phí: {r.get('cost')}\n")

        # MST
        if "edges" in r:
            self.text.insert("end", "Danh sách cạnh:\n")
            for u, v, w in r["edges"]:
                self.text.insert("end", f" - {u} — {v} (w={w})\n")
            self.text.insert("end", f"\nTổng chi phí: {r.get('cost')}\n")

        # COLORING
        if "coloring" in r:
            self.text.insert("end", f"Số màu sử dụng: {r.get('min_colors')}\n\n")
            self.text.insert("end", "Chi tiết tô màu:\n")
            for v, (hex_code, name) in r["coloring"].items():
                self.text.insert("end", f" - {v}: {name} ({hex_code})\n")

        # LONG EXPLANATION
        if "theory" in r:
            self.text.insert("end", "PHÂN TÍCH CHI TIẾT:\n\n")
            self.text.insert("end", r["theory"])

