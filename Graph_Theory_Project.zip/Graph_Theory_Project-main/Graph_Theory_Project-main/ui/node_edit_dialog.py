import customtkinter as ctk
from tkinter import messagebox


class NodeEditDialog(ctk.CTkToplevel):
    def __init__(self, master, node_name, graph_area, callback):
        super().__init__(master)

        # ===== WINDOW CONFIG =====
        self.title("NODE INFO")
        self.geometry("380x360")
        self.resizable(False, False)
        self.configure(fg_color="#1E1E1E")

        self.attributes("-topmost", True)
        self.focus_force()
        self.grab_set()

        self.node = node_name
        self.graph_area = graph_area
        self.callback = callback

        # ===== TITLE =====
        ctk.CTkLabel(
            self,
            text="THÔNG TIN ĐỈNH",
            font=("Roboto", 20, "bold"),
            text_color="#E5E7EB"
        ).pack(pady=(15, 10))

        # ===== INFO =====
        self._info_row("Tên đỉnh:", node_name)

        neighbors = graph_area.get_neighbors(node_name)
        degree = len(neighbors)
        neighbor_names = [v for (v, _) in neighbors]

        self._info_row("Bậc đỉnh:", str(degree))
        self._info_row(
            "Đỉnh kề:",
            ", ".join(neighbor_names) if neighbor_names else "Không có"
        )

        # ===== EDIT =====
        ctk.CTkLabel(
            self,
            text="SỬA TÊN ĐỈNH",
            text_color="#9CA3AF",
            font=("Roboto", 13)
        ).pack(pady=(15, 5))

        self.entry = ctk.CTkEntry(
            self,
            fg_color="#2A2A2A",
            border_color="#3A3A3A",
            text_color="#F9FAFB"
        )
        self.entry.insert(0, node_name)
        self.entry.pack(fill="x", padx=30, pady=(0, 10))

        # ===== BUTTON ROW =====
        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(pady=(10, 15), padx=30, fill="x")

        ctk.CTkButton(
            btn_row,
            text="LƯU",
            fg_color="#0EA5E9",
            hover_color="#0284C7",
            text_color="white",
            command=self.save
        ).pack(side="left", expand=True, fill="x", padx=(0, 8))

        ctk.CTkButton(
            btn_row,
            text="XÓA",
            fg_color="#EF4444",
            hover_color="#DC2626",
            text_color="white",
            command=self.delete
        ).pack(side="left", expand=True, fill="x", padx=(8, 0))

    # ===== INFO ROW =====
    def _info_row(self, label, value):
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=30, pady=4)

        ctk.CTkLabel(
            row,
            text=label,
            width=140,
            anchor="w",
            text_color="#9CA3AF",
            font=("Roboto", 13)
        ).pack(side="left")

        ctk.CTkLabel(
            row,
            text=value,
            anchor="w",
            text_color="#F3F4F6",
            font=("Roboto", 13, "bold")
        ).pack(side="left")

    # ===== ACTIONS =====
    def save(self):
        new = self.entry.get().strip()
        if not new:
            messagebox.showerror("Lỗi", "Tên đỉnh không được rỗng")
            return
        self.callback("update", self.node, new)
        self.destroy()

    def delete(self):
        if messagebox.askyesno("Xác nhận", "Xóa đỉnh này?"):
            self.callback("delete", self.node, None)
            self.destroy()
