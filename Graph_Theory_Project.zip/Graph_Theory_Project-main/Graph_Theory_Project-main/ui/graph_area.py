import tkinter as tk
import customtkinter as ctk
import math
import random

from ui.node_edit_dialog import NodeEditDialog
from ui.edge_edit_dialog import EdgeEditDialog


class GraphArea(ctk.CTkCanvas):
    def __init__(self, master):
        super().__init__(master, bg="#101113", highlightthickness=0)

        self.nodes = {}
        self.edges = []  # (u, v, w, directed)
        self.radius = 25  # Bán kính node

        self.drag_node = None
        self.drag_offset = (0, 0)

        self.node_colors = {}   # {node_id: "#HEX"}
        self.graph_type = None

        self.bind("<Button-1>", self.on_click)
        self.bind("<B1-Motion>", self.on_drag)
        self.bind("<ButtonRelease-1>", self.on_release)
        self.bind("<Double-Button-1>", self.on_double_click)

    # ================= NODE =================
    def add_node(self, name, x=None, y=None):
        if name in self.nodes:
            return
        if x is None:
            x = 250 + len(self.nodes) * 70
        if y is None:
            y = 220
        self.nodes[name] = {"x": x, "y": y, "loop_dir": (1, 0)}
        self.redraw()

    def delete_node(self, name):
        if name not in self.nodes:
            return
        self.nodes.pop(name)
        self.edges = [(u, v, w, d) for (u, v, w, d) in self.edges if u != name and v != name]
        if name in self.node_colors:
            del self.node_colors[name]
        self.redraw()

    # ================= EDGE =================
    def add_edge(self, u, v, w=None, directed=False):
        if w is None:
            w = random.randint(1, 20)

        if self.graph_type is None:
            self.graph_type = "directed" if directed else "undirected"
        else:
            if self.graph_type == "undirected":
                directed = False
            elif self.graph_type == "directed":
                directed = True

        self.edges.append((u, v, w, directed))
        self.redraw()

    def delete_edge(self, u, v):
        self.edges = [
            (x, y, w, d)
            for (x, y, w, d) in self.edges
            if not ((x == u and y == v) or (not d and x == v and y == u))
        ]
        if not self.edges:
            self.graph_type = None
        self.redraw()

    # ================= CLEAR =================
    def clear_all(self):
        self.nodes.clear()
        self.edges.clear()
        self.graph_type = None
        self.node_colors = {}
        self.delete("all")

    # ================= DRAW =================
    def redraw(self):
        self.delete("all")

        # Gom nhóm cạnh song song (Multigraph)
        groups = {}
        for idx, (u, v, w, d) in enumerate(self.edges):
            if u == v:
                continue
            key = ("dir", u, v) if d else ("und", *sorted([u, v]))
            groups.setdefault(key, []).append(idx)

        parallel_info = {}
        for idxs in groups.values():
            # Chỉ tính toán vị trí song song nếu có > 1 cạnh nối cùng cặp đỉnh
            if len(idxs) > 1:
                count = len(idxs)
                for k, edge_idx in enumerate(idxs):
                    pos = k - (count - 1) / 2
                    parallel_info[edge_idx] = pos
            else:
                # Nếu chỉ có 1 cạnh, pos = 0 (Vẽ thẳng)
                parallel_info[idxs[0]] = 0

        # Vẽ cạnh TRƯỚC (nằm dưới)
        for idx, (u, v, w, d) in enumerate(self.edges):
            self.draw_edge(u, v, w, d, parallel_info.get(idx, 0))

        # Vẽ node SAU (nằm trên)
        for n, nd in self.nodes.items():
            self.draw_node(n, nd["x"], nd["y"])

    def draw_node(self, name, x, y):
        r = self.radius
        fill_color = self.node_colors.get(name, "#0E0F11")

        self.nodes[name]["circle"] = self.create_oval(
            x - r, y - r, x + r, y + r,
            outline="#00AEEF", width=3,
            fill=fill_color,
            tags=("node", f"node_{name}")
        )
        self.nodes[name]["label"] = self.create_text(
            x, y, text=name,
            fill="white",
            font=("Consolas", 16, "bold")
        )

    def draw_edge(self, u, v, w, directed, parallel_pos=0):
        if u not in self.nodes or v not in self.nodes:
            return

        ux, uy = self.nodes[u]["x"], self.nodes[u]["y"]
        vx, vy = self.nodes[v]["x"], self.nodes[v]["y"]

        # Seed ngẫu nhiên cố định theo cặp cạnh để vị trí text không bị nhảy khi redraw
        seed_val = sum(ord(c) for c in u+v) + int(w)
        random.seed(seed_val)

        # --- SELF-LOOP ---
        if u == v:
            dx, dy = self.nodes[u].get("loop_dir", (0, -1))
            l = math.hypot(dx, dy) or 1
            dx, dy = dx / l, dy / l
            
            start_x = ux + dx * (self.radius * 0.5)
            start_y = uy + dy * (self.radius * 0.5)
            
            cx, cy = start_x + dx * 55, start_y + dy * 55
            loop_r = 35

            self.create_oval(
                cx - loop_r, cy - loop_r, cx + loop_r, cy + loop_r,
                outline="#00AEEF", width=3,
                tags=("edge", f"edge_{u}_{v}")
            )
            
            if directed:
                arrow_x = cx - dy * loop_r
                arrow_y = cy + dx * loop_r
                self.create_line(
                    arrow_x, arrow_y, arrow_x + dx*5, arrow_y + dy*5, 
                    arrow=tk.LAST, fill="#00AEEF", width=3, tags=("edge", f"edge_{u}_{v}")
                )
            
            tx, ty = cx + dx * 40, cy + dy * 40
            self._draw_text_with_bg(tx, ty, str(w))
            return

        # --- CẠNH THƯỜNG ---
        dx, dy = vx - ux, vy - uy
        dist = math.hypot(dx, dy) or 1
        
        # Điểm bắt đầu và kết thúc tại VIỀN Node
        off_x = (dx / dist) * self.radius
        off_y = (dy / dist) * self.radius
        
        real_ux, real_uy = ux + off_x, uy + off_y
        real_vx, real_vy = vx - off_x, vy - off_y

        mid_x, mid_y = (real_ux + real_vx) / 2, (real_uy + real_vy) / 2

        # --- XỬ LÝ HÌNH DÁNG DÂY ---
        
        # Nếu parallel_pos = 0: Vẽ THẲNG TẮP
        if parallel_pos == 0:
            coords = (real_ux, real_uy, real_vx, real_vy)
            smooth_opt = False
            
            # --- XỬ LÝ TEXT NÉ NHAU ---
            # Random vị trí text trên dây từ 30% đến 70% quãng đường
            # Giúp các số không chồng đống lên nhau ở giữa
            t = random.uniform(0.3, 0.7)
            
            text_pos_x = real_ux + (real_vx - real_ux) * t
            text_pos_y = real_uy + (real_vy - real_uy) * t

        # Nếu parallel_pos != 0: Vẽ CONG (để tách các cạnh song song)
        else:
            offset_scale = 40 
            perp_x, perp_y = -dy / dist, dx / dist
            
            ctrl_x = mid_x + perp_x * (parallel_pos * offset_scale)
            ctrl_y = mid_y + perp_y * (parallel_pos * offset_scale)
            
            coords = (real_ux, real_uy, ctrl_x, ctrl_y, real_vx, real_vy)
            smooth_opt = True
            
            # Với đường cong, text nằm ở đỉnh cong là đẹp nhất
            text_pos_x, text_pos_y = ctrl_x, ctrl_y

        arrow_opt = tk.LAST if directed else None 
        
        self.create_line(
            *coords,
            fill="#00AEEF", 
            width=2,
            smooth=smooth_opt,
            arrow=arrow_opt,
            arrowshape=(12, 15, 5),
            tags=("edge", f"edge_{u}_{v}")
        )

        # Vẽ trọng số có nền đen
        self._draw_text_with_bg(text_pos_x, text_pos_y, str(w), tags=("edge_text", f"text_{u}_{v}"))

    def _draw_text_with_bg(self, x, y, text, tags=None):
        """Hàm phụ trợ: Vẽ text có hình chữ nhật nền phía sau"""
        w_rect = len(text) * 9 + 8
        h_rect = 18
        
        x1, y1 = x - w_rect/2, y - h_rect/2
        x2, y2 = x + w_rect/2, y + h_rect/2
        
        self.create_rectangle(
            x1, y1, x2, y2,
            fill="#101113", # Màu nền trùng màu canvas để che dây
            outline="",
            tags=tags
        )
        
        self.create_text(
            x, y,
            text=text, 
            fill="yellow",
            font=("Consolas", 12, "bold"),
            anchor="center", 
            tags=tags
        )

    # ================= EVENTS (GIỮ NGUYÊN) =================
    def highlight_edge(self, u, v, color):
        for tag in (f"edge_{u}_{v}", f"edge_{v}_{u}"):
            for i in self.find_withtag(tag):
                self.itemconfig(i, fill=color)

    def clear_highlight(self):
        for i in self.find_withtag("edge"):
            self.itemconfig(i, fill="#00AEEF")

    def on_click(self, e):
        for n, d in self.nodes.items():
            if d["circle"] in self.find_overlapping(e.x, e.y, e.x, e.y):
                self.drag_node = n
                self.drag_offset = (d["x"] - e.x, d["y"] - e.y)
                return

    def on_drag(self, e):
        if not self.drag_node:
            return
        nx = e.x + self.drag_offset[0]
        ny = e.y + self.drag_offset[1]
        ox, oy = self.nodes[self.drag_node]["x"], self.nodes[self.drag_node]["y"]
        self.nodes[self.drag_node]["x"] = nx
        self.nodes[self.drag_node]["y"] = ny
        self.nodes[self.drag_node]["loop_dir"] = (nx - ox, ny - oy)
        self.redraw()

    def on_release(self, e):
        self.drag_node = None

    def get_neighbors(self, node):
        res = []
        for (u, v, w, d) in self.edges:
            if u == node:
                res.append((v, w))
            if not d and v == node:
                res.append((u, w))
        return res

    def open_node_editor(self, name):
        NodeEditDialog(self.master, name, self,
            lambda a, o, n: self._rename_node(o, n) if a == "update" else self.delete_node(o))

    def _rename_node(self, old, new):
        if not new or new in self.nodes: return
        self.nodes[new] = self.nodes.pop(old)
        self.edges = [(new if u == old else u, new if v == old else v, w, d) for (u, v, w, d) in self.edges]
        if old in self.node_colors: self.node_colors[new] = self.node_colors.pop(old)
        self.redraw()

    def open_edge_editor(self, u, v, w, directed):
        def cb(action, u2, v2, w2, d2):
            if self.graph_type == "undirected": d2 = False
            elif self.graph_type == "directed": d2 = True
            if action == "update":
                self.delete_edge(u, v)
                self.add_edge(u2, v2, w2, d2)
            elif action == "delete":
                self.delete_edge(u, v)
        EdgeEditDialog(self.master, u, v, w, directed, self, cb)

    def reset_node_colors(self):
        self.node_colors = {}
        self.redraw()

    def set_node_color(self, node, color_hex):
        self.node_colors[node] = color_hex
        self.redraw()

    def on_double_click(self, e):
        x, y = e.x, e.y
        for n, d in self.nodes.items():
            if (x - d["x"]) ** 2 + (y - d["y"]) ** 2 <= self.radius ** 2:
                self.open_node_editor(n)
                return
        for (u, v, w, directed) in self.edges:
            if self._near_edge(x, y, u, v):
                self.open_edge_editor(u, v, w, directed)
                return

    def _near_edge(self, px, py, u, v, tol=8):
        if u not in self.nodes or v not in self.nodes: return False
        x1, y1 = self.nodes[u]["x"], self.nodes[u]["y"]
        x2, y2 = self.nodes[v]["x"], self.nodes[v]["y"]
        dx, dy = x2 - x1, y2 - y1
        if dx == dy == 0: return False
        t = ((px - x1) * dx + (py - y1) * dy) / (dx*dx + dy*dy)
        t = max(0, min(1, t))
        cx = x1 + t * dx
        cy = y1 + t * dy
        return (px - cx)**2 + (py - cy)**2 <= tol**2

    def auto_layout(self):
        if not self.nodes: return
        self.update_idletasks()
        w = self.winfo_width()
        h = self.winfo_height()
        if w <= 1: w = 900
        if h <= 1: h = 500
        cx, cy = w / 2, h / 2
        R = min(w, h) * 0.35
        names = list(self.nodes.keys())
        for i, name in enumerate(names):
            angle = 2 * math.pi * i / len(names)
            self.nodes[name]["x"] = cx + R * math.cos(angle)
            self.nodes[name]["y"] = cy + R * math.sin(angle)
        self.redraw()