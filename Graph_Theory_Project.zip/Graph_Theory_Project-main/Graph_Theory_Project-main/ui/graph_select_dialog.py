import customtkinter as ctk
from tkinter import messagebox
import math

def _draw_preview_from_janus(self, canvas, graph_id):
    canvas.delete("all")

    nodes = self.master.engine.janus_service.get_nodes(graph_id)
    edges = self.master.engine.janus_service.get_edges(graph_id)

    if not nodes:
        return

    w = canvas.winfo_width()
    h = canvas.winfo_height()
    cx, cy = w // 2, h // 2
    r = min(w, h) // 2 - 15

    n = len(nodes)
    pos = {}

    for i, node in enumerate(nodes):
        angle = 2 * math.pi * i / n
        x = cx + r * math.cos(angle)
        y = cy + r * math.sin(angle)
        pos[node["name"]] = (x, y)

    # edges
    for u, v in edges:
        if u in pos and v in pos:
            canvas.create_line(*pos[u], *pos[v],
                               fill="#94A3B8", width=1.5)

    # nodes
    for x, y in pos.values():
        canvas.create_oval(x-4, y-4, x+4, y+4,
                           fill="#22D3EE", outline="")



class GraphSelectDialog(ctk.CTkToplevel):
    def __init__(self, master, graphs, on_select):
        super().__init__(master)
        self.graphs = graphs
        self.on_select = on_select
        self.engine = master.engine 

        self.attributes("-topmost", True)
        self.focus_force()
        self.grab_set()

        self.title("Chọn đồ thị từ JanusGraph")
        self.geometry("760x540")
        self.resizable(False, False)

        self.build_ui()

    # ======================================================
    def build_ui(self):
        container = ctk.CTkScrollableFrame(self)
        container.pack(fill="both", expand=True, padx=10, pady=10)

        if not self.graphs:
            ctk.CTkLabel(
                container,
                text="Không có đồ thị nào trong JanusGraph.",
                font=("Roboto", 16, "bold")
            ).pack(pady=40)
            return

        for g in self.graphs:
            card = ctk.CTkFrame(container)
            card.pack(fill="x", pady=8)

            top = ctk.CTkFrame(card, fg_color="transparent")
            top.pack(fill="x", padx=8, pady=6)

            info = (
                f"Tên đồ thị: {g.get('name','')}\n"
                f"ID đồ thị: {g.get('graph_id','')}\n"
                f"Loại đồ thị: {'Có hướng' if g.get('directed') else 'Vô hướng'}\n"
                f"Số đỉnh: {g.get('node_count',0)} | "
                f"Số cạnh: {g.get('edge_count',0)}\n"
                f"Thời gian lưu: {g.get('saved_at_str','N/A')}\n"
                f"Mô tả: {g.get('description','')}"
            )

            ctk.CTkLabel(
                top, text=info, justify="left",
                font=("Consolas", 13)
            ).pack(side="left", padx=6)

            # ===== PREVIEW CANVAS =====
            canvas = ctk.CTkCanvas(
                top, width=160, height=110,
                bg="#0F172A",
                highlightthickness=1,
                highlightbackground="#334155"
            )
            canvas.pack(side="right", padx=8)

            canvas.after(
                50,
                lambda c=canvas, gid=g["graph_id"]:
                self._draw_preview_from_janus(c, gid)
            )

            # ===== BUTTON BAR =====
            btn_bar = ctk.CTkFrame(card, fg_color="transparent")
            btn_bar.pack(pady=(0, 6))

            ctk.CTkButton(
                btn_bar,
                text="CHỌN ĐỒ THỊ",
                fg_color="#22C55E",
                command=lambda meta=g: self._select(meta)
            ).pack(side="left", padx=6)

            ctk.CTkButton(
                btn_bar,
                text="XÓA ĐỒ THỊ",
                fg_color="#EF4444",
                command=lambda meta=g: self._delete(meta)
            ).pack(side="left", padx=6)

    # ======================================================
    def _select(self, graph_meta):
        self.on_select(graph_meta)
        self.destroy()

    def _delete(self, g):
        if not messagebox.askyesno(
            "Xác nhận",
            f"Xóa đồ thị '{g.get('name','')}'?\nHành động không thể hoàn tác."
        ):
            return

        ok = self.master.engine.delete_janus_graph(g["graph_id"])
        if ok:
            self.destroy()
            GraphSelectDialog(
                self.master,
                self.master.engine.get_janus_graph_list(),
                self.on_select
            )

    # ======================================================
    def _draw_preview_from_janus(self, canvas, graph_id):
        canvas.delete("all")

        nodes, edges = self.engine.janus_service.load_graph(graph_id)
        if not nodes:
            return

        xs = [n["x"] for n in nodes]
        ys = [n["y"] for n in nodes]

        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)

        cw, ch = canvas.winfo_width(), canvas.winfo_height()
        pad = 10

        def map_pos(x, y):
            return (
                pad + (x - min_x) / max(1, max_x - min_x) * (cw - 2 * pad),
                pad + (y - min_y) / max(1, max_y - min_y) * (ch - 2 * pad)
            )

        pos = {n["name"]: map_pos(n["x"], n["y"]) for n in nodes}

        for e in edges:
            u, v = e["u"], e["v"]
            if u in pos and v in pos:
                canvas.create_line(
                    *pos[u], *pos[v],
                    fill="#94A3B8", width=1.5
                )

        for x, y in pos.values():
            canvas.create_oval(
                x - 4, y - 4, x + 4, y + 4,
                fill="#22D3EE", outline=""
            )


