import customtkinter as ctk
# Dùng import tương đối (dấu chấm) vì file này nằm trong thư mục ui
from .left_panel import LeftPanel
from .graph_area import GraphArea
from .log_panel import LogPanel
from .result_panel import ResultPanel
from .algorithm_engine import AlgorithmEngine

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class AppWindow(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Graph Visualizer - CustomTkinter")
        self.geometry("1700x920")
        self.minsize(1300, 700)
        self.configure(fg_color="#1A1B1E")

        # =============== LAYOUT ===============
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # 1. Khai báo biến LeftPanel (chưa tạo vội)
        self.left_panel = None

        # 2. Tạo phần khung bên phải trước (Graph, Log, Result)
        # RIGHT PANEL
        self.right_panel = ctk.CTkFrame(self, fg_color="#1F2124")
        self.right_panel.grid(row=0, column=1, sticky="nsew")
        self.right_panel.grid_columnconfigure(0, weight=1)
        self.right_panel.grid_rowconfigure(0, weight=4)
        self.right_panel.grid_rowconfigure(1, weight=2)

        # GRAPH AREA
        self.graph_area = GraphArea(self.right_panel)
        self.graph_area.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)

        # BOTTOM AREA
        self.bottom = ctk.CTkFrame(self.right_panel, fg_color="#1A1B1E")
        self.bottom.grid(row=1, column=0, sticky="nsew")
        self.bottom.grid_columnconfigure(0, weight=3)
        self.bottom.grid_columnconfigure(1, weight=2)
        self.bottom.grid_rowconfigure(0, weight=1)

        # LOG PANEL
        self.log_panel = LogPanel(self.bottom)
        self.log_panel.grid(row=0, column=0, sticky="nsew", padx=(10, 5), pady=10)

        # RESULT PANEL
        self.result_panel = ResultPanel(self.bottom)
        self.result_panel.grid(row=0, column=1, sticky="nsew", padx=(5, 10), pady=10)

        # 3. KẾT NỐI ENGINE (QUAN TRỌNG: Tạo Engine trước LeftPanel)
        # Truyền đúng các tham số keyword cho AlgorithmEngine mới
        self.engine = AlgorithmEngine(
            graph_area=self.graph_area,
            log_panel=self.log_panel,
            result_panel=self.result_panel
        )

        # 4. Tạo Left Panel (Bảng điều khiển) sau cùng
        # Để đảm bảo self.engine đã có sẵn nếu LeftPanel cần dùng
        self.left_panel = LeftPanel(self)
        self.left_panel.grid(row=0, column=0, sticky="nsw")

        # RESIZERS (Để trang trí)
        self.left_resizer = ctk.CTkFrame(self, width=8, fg_color="#2B2D31")
        self.left_resizer.grid(row=0, column=0, sticky="nse")
        
        self.mid_resizer = ctk.CTkFrame(self.bottom, width=8, fg_color="#2B2D31")
        self.mid_resizer.grid(row=0, column=0, sticky="ne")

    # Các hàm resize giữ nguyên (pass)
    def start_resize_left(self, e): pass
    def do_resize_left(self, e): pass
    def start_resize_mid(self, e): pass
    def do_resize_mid(self, e): pass