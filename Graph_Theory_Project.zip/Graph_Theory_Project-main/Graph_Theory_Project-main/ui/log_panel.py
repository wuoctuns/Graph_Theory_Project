import customtkinter as ctk


class LogPanel(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color="#151617", corner_radius=10)

        # Title
        self.title = ctk.CTkLabel(
            self,
            text="LOG HOẠT ĐỘNG",
            font=("Roboto", 17, "bold"),
            anchor="center"
        )
        self.title.pack(pady=(8, 5))

        # Textbox
        self.textbox = ctk.CTkTextbox(
            self,
            fg_color="#0E0F10",
            text_color="white",
            font=("Consolas", 15),  # tăng size chữ log
            wrap="none",
            corner_radius=10
        )
        self.textbox.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.textbox.configure(state="disabled")

    # ======================================================
    # WRITE LOG ENTRY
    # ======================================================
    def write(self, msg: str):
        self.textbox.configure(state="normal")
        self.textbox.insert("end", f"{msg}\n")
        self.textbox.configure(state="disabled")
        self.textbox.yview_moveto(1)  # auto scroll
