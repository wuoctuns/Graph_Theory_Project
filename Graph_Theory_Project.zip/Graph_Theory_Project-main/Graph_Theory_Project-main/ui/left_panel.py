import customtkinter as ctk
from tkinter import messagebox
import random
import math
from ui.path_dialog import PathDialog
from ui.start_dialog import StartDialog
from ui.graph_save_dialog import GraphSaveDialog
from ui.graph_select_dialog import GraphSelectDialog


class LeftPanel(ctk.CTkScrollableFrame):
    """
    Bảng điều khiển bên trái
    """
    def __init__(self, master):
        super().__init__(
            master,
            width=320,
            fg_color="#222428",
            scrollbar_fg_color="#222428",
            scrollbar_button_color="#3B3F46",
            scrollbar_button_hover_color="#4B5563",
        )
        self.master = master
        self.undo_stack = []
        self.build_ui()

    # ============================================================
    # BUILD UI
    # ============================================================
    def build_ui(self):
        title = ctk.CTkLabel(self, text="BẢNG ĐIỀU KHIỂN", font=("Roboto", 22, "bold"))
        title.pack(pady=(15, 10))

        mode_title = ctk.CTkLabel(self, text="LOẠI ĐỒ THỊ", font=("Roboto", 17, "bold"))
        mode_title.pack(pady=(8, 3))

        mode_frame = ctk.CTkFrame(self, fg_color="transparent")
        mode_frame.pack(fill="x", padx=15)

        self.graph_directed_var = ctk.BooleanVar(value=False)

        ctk.CTkRadioButton(
            mode_frame, text="Đồ thị vô hướng",
            variable=self.graph_directed_var, value=False
        ).pack(side="left", padx=3)

        ctk.CTkRadioButton(
            mode_frame, text="Đồ thị có hướng",
            variable=self.graph_directed_var, value=True
        ).pack(side="right", padx=3)

        # ---- VERTEX SETTING ----
        vtitle = ctk.CTkLabel(self, text="VERTEX SETTING", font=("Roboto", 17, "bold"))
        vtitle.pack(pady=(5, 3))

        self.vertex_entry = ctk.CTkEntry(self, placeholder_text="Tên đỉnh...")
        self.vertex_entry.pack(fill="x", padx=15, pady=5)

        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=15)

        ctk.CTkButton(btn_frame, text="Thêm đỉnh", fg_color="#0EA5E9", command=self.add_vertex)\
            .pack(side="left", expand=True, padx=3, pady=5)

        ctk.CTkButton(btn_frame, text="Xóa đỉnh", fg_color="#EF4444", command=self.delete_vertex)\
            .pack(side="left", expand=True, padx=3, pady=5)

        self.vertex_entry.bind("<Return>", lambda e: self.add_vertex())

        # ---- EDGE SETTING ----
        etitle = ctk.CTkLabel(self, text="EDGE SETTING", font=("Roboto", 17, "bold"))
        etitle.pack(pady=(15, 3))

        self.edge_u = ctk.CTkEntry(self, placeholder_text="Đỉnh u...")
        self.edge_u.pack(fill="x", padx=15, pady=5)

        self.edge_v = ctk.CTkEntry(self, placeholder_text="Đỉnh v...")
        self.edge_v.pack(fill="x", padx=15, pady=5)

        self.edge_w = ctk.CTkEntry(self, placeholder_text="Trọng số...")
        self.edge_w.pack(fill="x", padx=15, pady=5)

        ebtn_frame = ctk.CTkFrame(self, fg_color="transparent")
        ebtn_frame.pack(fill="x", padx=15)

        ctk.CTkButton(ebtn_frame, text="Thêm cạnh", fg_color="#0EA5E9", command=self.add_edge)\
            .pack(side="left", expand=True, padx=3, pady=5)

        ctk.CTkButton(ebtn_frame, text="Xóa cạnh", fg_color="#EF4444", command=self.delete_edge)\
            .pack(side="left", expand=True, padx=3, pady=5)

        self.edge_w.bind("<Return>", lambda e: self.add_edge())

        # ---- GRAPH GENERATOR ----
        gtitle = ctk.CTkLabel(self, text="GRAPH GENERATOR", font=("Roboto", 16, "bold"))
        gtitle.pack(pady=(15, 3))

        self.gen_type = ctk.StringVar(value="Ngôi sao (Star)")

        gen_menu = ctk.CTkOptionMenu(
            self,
            values=[
                "Ngôi sao (Star)",
                "Lưới (Grid)",
                "Phân tầng (Layered)",
                "Vòng tròn / Chu trình (Cycle)",
                "Đầy đủ (Complete)",
                "Cây nhị phân (Binary Tree)",
                "Hai phía (Bipartite)",
                "Ngẫu nhiên (Random)"
            ],
            variable=self.gen_type
        )
        gen_menu.pack(fill="x", padx=15, pady=3)

        ctk.CTkButton(
            self, text="TẠO ĐỒ THỊ MẪU",
            fg_color="#22C55E",
            command=self.generate_graph
        ).pack(fill="x", padx=15, pady=(3, 10))

        # ---- ALGORITHM ----
        atitle = ctk.CTkLabel(self, text="ALGORITHM", font=("Roboto", 16, "bold"))
        atitle.pack(pady=(15, 3))

        self.algos = [
            "Duyệt theo chiều rộng (BFS)",
            "Duyệt theo chiều sâu (DFS)",
            "Đường đi ngắn nhất (Dijkstra)",
            "Đường đi ngắn nhất (Bellman–Ford)",
            "Cây khung nhỏ nhất (Prim)",
            "Cây khung nhỏ nhất (Kruskal)",
            "Đường đi Euler",
            "Chu trình Euler",
            "Đường đi Hamilton",
            "Chu trình Hamilton",
            "Tô màu đồ thị (Coloring)"
        ]

        self.algo_var = ctk.StringVar(value=self.algos[0])
        self.algo_menu = ctk.CTkOptionMenu(self, values=self.algos, variable=self.algo_var)
        self.algo_menu.pack(fill="x", padx=15)

        ctk.CTkButton(self, text="CHẠY THUẬT TOÁN", fg_color="#0EA5E9", command=self.run_algorithm)\
            .pack(fill="x", padx=15, pady=(8, 3))

        ctk.CTkButton(self, text="HOÀN TÁC", fg_color="#6B7280", command=self.undo)\
            .pack(fill="x", padx=15, pady=3)

        ctk.CTkButton(self, text="XÓA TẤT CẢ", fg_color="#D83C3C", command=self.clear_all)\
            .pack(fill="x", padx=15, pady=(5, 10))

        # ---- JANUSGRAPH ----
        jtitle = ctk.CTkLabel(self, text="JANUSGRAPH", font=("Roboto", 16, "bold"))
        jtitle.pack(pady=(15, 3))

        ctk.CTkButton(self, text="KẾT NỐI JANUSGRAPH", fg_color="#10B981", command=self.connect_janus)\
            .pack(fill="x", padx=15, pady=3)

        ctk.CTkButton(self, text="GỬI LÊN JANUSGRAPH", fg_color="#3B82F6", command=self.upload_to_janus)\
            .pack(fill="x", padx=15, pady=3)

        ctk.CTkButton(self, text="NHẬN TỪ JANUSGRAPH", fg_color="#F59E0B", command=self.load_from_janus)\
            .pack(fill="x", padx=15, pady=(3, 15))

    # ============================================================
    # FUNCTIONS
    # ============================================================
    def add_vertex(self):
        name = self.vertex_entry.get().strip()
        if name == "":
            messagebox.showerror("Lỗi", "Tên đỉnh không được rỗng.")
            return
        if name in self.master.graph_area.nodes:
            messagebox.showerror("Lỗi", "Đỉnh đã tồn tại.")
            return

        self.undo_stack.append(("del_vertex", name))
        self.master.graph_area.add_node(name)
        self.master.log_panel.write(f"Thêm đỉnh: {name}")
        self.vertex_entry.delete(0, "end")

    def delete_vertex(self):
        name = self.vertex_entry.get().strip()
        if name not in self.master.graph_area.nodes:
            messagebox.showerror("Lỗi", f"Đỉnh '{name}' không tồn tại.")
            return
        if not messagebox.askyesno("Xác nhận", f"Xóa đỉnh '{name}'?"):
            return

        edges = [(u, v, w, d) for (u, v, w, d) in self.master.graph_area.edges if u == name or v == name]
        self.undo_stack.append(("add_vertex", name, edges))
        self.master.graph_area.delete_node(name)
        self.master.log_panel.write(f"Xóa đỉnh: {name}")

    def add_edge(self):
        u = self.edge_u.get().strip()
        v = self.edge_v.get().strip()
        w = self.edge_w.get().strip()
        g = self.master.graph_area

        if u not in g.nodes or v not in g.nodes:
            messagebox.showerror("Lỗi", "Đỉnh không tồn tại.")
            return
        if not w.isdigit() and not (w.startswith('-') and w[1:].isdigit()):
            messagebox.showerror("Lỗi", "Trọng số phải là số (có thể âm).")
            return

        want_directed = bool(self.graph_directed_var.get())

        if g.graph_type is not None:
            if g.graph_type == "undirected" and want_directed:
                messagebox.showerror("Lỗi", "Đồ thị hiện tại là VÔ HƯỚNG.")
                return
            if g.graph_type == "directed" and not want_directed:
                messagebox.showerror("Lỗi", "Đồ thị hiện tại là CÓ HƯỚNG.")
                return

        g.add_edge(u, v, int(w), want_directed)
        arrow = "→" if want_directed else "–"
        self.master.log_panel.write(f"Thêm cạnh: {u} {arrow} {v} (w={w})")

    def delete_edge(self):
        u = self.edge_u.get().strip()
        v = self.edge_v.get().strip()
        all_edges = self.master.graph_area.edges[:]
        target = None
        for (a, b, w, d) in all_edges:
            if a == u and b == v:
                target = (u, v, w, d)
                break
        if not target:
            messagebox.showerror("Lỗi", "Cạnh không tồn tại.")
            return
        if not messagebox.askyesno("Xác nhận", f"Xóa cạnh {u} → {v}?"): return

        self.undo_stack.append(("add_edge", *target))
        self.master.graph_area.delete_edge(u, v)
        self.master.log_panel.write(f"Xóa cạnh: {u} → {v}")

    def undo(self):
        if not self.undo_stack:
            messagebox.showinfo("Undo", "Không còn thao tác.")
            return
        action = self.undo_stack.pop()
        t = action[0]

        if t == "del_vertex":
            name = action[1]
            self.master.graph_area.delete_node(name)
            self.master.log_panel.write(f"UNDO: xóa đỉnh {name}")
        elif t == "add_vertex":
            name, edges = action[1], action[2]
            self.master.graph_area.add_node(name)
            for (u, v, w, d) in edges: self.master.graph_area.add_edge(u, v, w, d)
            self.master.log_panel.write(f"UNDO: khôi phục đỉnh {name}")
        elif t == "del_edge":
            u, v = action[1], action[2]
            self.master.graph_area.delete_edge(u, v)
            self.master.log_panel.write(f"UNDO: xóa cạnh {u} – {v}")
        elif t == "add_edge":
            u, v, w, d = action[1], action[2], action[3], action[4]
            self.master.graph_area.add_edge(u, v, w, d)
            arrow = "→" if d else "–"
            self.master.log_panel.write(f"UNDO: khôi phục cạnh {u} {arrow} {v} (w={w})")
        elif t == "restore_all":
            for n in action[1]: self.master.graph_area.add_node(n)
            for (u, v, w, d) in action[2]: self.master.graph_area.add_edge(u, v, w, d)
            self.master.log_panel.write("UNDO: khôi phục toàn bộ đồ thị")
        self.master.graph_area.redraw()

    def clear_all(self):
        if not messagebox.askyesno("Xác nhận", "Xóa toàn bộ đồ thị?"): return
        nodes = list(self.master.graph_area.nodes.keys())
        edges = list(self.master.graph_area.edges)
        self.undo_stack.append(("restore_all", nodes, edges))
        self.master.graph_area.clear_all()
        self.master.log_panel.write("Đã xóa toàn bộ đồ thị.")

    def run_algorithm(self):
        algo = self.algo_var.get()
        engine = self.master.engine
        self.master.graph_area.reset_node_colors()
        self.master.graph_area.redraw()

        if algo == "Duyệt theo chiều rộng (BFS)":
            StartDialog(self.master, lambda s: self.master.result_panel.show(engine.bfs(s)))
        elif algo == "Duyệt theo chiều sâu (DFS)":
            StartDialog(self.master, lambda s: self.master.result_panel.show(engine.dfs(s)))
        elif algo in ["Đường đi ngắn nhất (Dijkstra)", "Đường đi ngắn nhất (Bellman–Ford)"]:
            def cb(s, g):
                r = engine.dijkstra(s, g) if algo == "Đường đi ngắn nhất (Dijkstra)" else engine.bellman_ford(s, g)
                if r.get("success") and r.get("path"): engine.animate_path(r["path"])
                self.master.result_panel.show(r)
            PathDialog(self.master, cb)
        elif algo in ["Đường đi Euler", "Chu trình Euler"]:
            r = engine.euler_path() if algo == "Đường đi Euler" else engine.euler_cycle()
            if r.get("success") and r.get("path"): engine.animate_path(r["path"])
            self.master.result_panel.show(r)
        elif algo in ["Đường đi Hamilton", "Chu trình Hamilton"]:
            mode = "path" if algo == "Đường đi Hamilton" else "cycle"
            r = engine.hamilton(mode=mode)
            if r.get("success") and r.get("path"): engine.animate_path(r["path"])
            self.master.result_panel.show(r)
        elif algo == "Tô màu đồ thị (Coloring)":
            self.master.result_panel.show(engine.color_graph())
        elif algo == "Cây khung nhỏ nhất (Prim)":
            r = engine.prim(next(iter(self.master.graph_area.nodes), None))
            if r["success"]: engine.animate_mst(r["edges"])
            self.master.result_panel.show(r)
        elif algo == "Cây khung nhỏ nhất (Kruskal)":
            r = engine.kruskal()
            if r["success"]: engine.animate_mst(r["edges"])
            self.master.result_panel.show(r)

    def connect_janus(self):
        self.master.engine.connect_janusgraph()

    def upload_to_janus(self):
        def cb(meta):
            g = self.master.graph_area
            meta["directed"] = (g.graph_type == "directed")
            self.master.engine.upload_graph_to_janusgraph(meta)
        GraphSaveDialog(self.master, self.master.graph_area, cb)

    def load_from_janus(self):
        graphs = self.master.engine.get_janus_graph_list()
        if not graphs:
            messagebox.showinfo("JanusGraph", "Không có đồ thị nào.")
            return
        def on_select(graph_meta):
            if self.master.engine.load_graph_from_janusgraph(graph_meta["graph_id"]):
                g = self.master.graph_area
                if g.edges:
                    directed = g.edges[0][3]
                    g.graph_type = "directed" if directed else "undirected"
                    self.graph_directed_var.set(directed)
                else:
                    g.graph_type = None
                    self.graph_directed_var.set(False)
        GraphSelectDialog(self.master, graphs, on_select)

    # ============================================================
    # GRAPH GENERATOR
    # ============================================================
    def generate_graph(self):
        g = self.master.graph_area
        g.clear_all()
        g.reset_node_colors()

        directed = bool(self.graph_directed_var.get())
        t = self.gen_type.get()
        g.update_idletasks()
        w = max(g.winfo_width(), 900)
        h = max(g.winfo_height(), 520)
        pad_x, pad_y = 90, 80

        def gen_names(n):
            if n <= 26: return [chr(ord("A") + i) for i in range(n)]
            names = []
            for i in range(n):
                names.append(chr(ord("A") + (i % 26)) + (str(i // 26) if i >= 26 else ""))
            return names

        if "Star" in t:
            names = gen_names(7)
            cx, cy = w * 0.45, h * 0.5
            g.add_node(names[0], x=cx, y=cy)
            R = min(w, h) * 0.33
            for i, n in enumerate(names[1:]):
                ang = 2 * math.pi * i / (len(names) - 1)
                g.add_node(n, x=cx + R * math.cos(ang), y=cy + R * math.sin(ang))
                g.add_edge(names[0], n, random.randint(1, 20), directed)

        elif "Grid" in t:
            rows, cols = 4, 5
            names = gen_names(rows * cols)
            dx, dy = (w - 2 * pad_x) / (cols - 1), (h - 2 * pad_y) / (rows - 1)
            pos = {}
            for r in range(rows):
                for c in range(cols):
                    idx = r * cols + c
                    g.add_node(names[idx], x=pad_x + c * dx, y=pad_y + r * dy)
                    pos[(r, c)] = names[idx]
            for r in range(rows):
                for c in range(cols):
                    if c + 1 < cols: g.add_edge(pos[(r, c)], pos[(r, c+1)], random.randint(1, 20), directed)
                    if r + 1 < rows: g.add_edge(pos[(r, c)], pos[(r+1, c)], random.randint(1, 20), directed)

        elif "Layered" in t:
            layers = [3, 4, 3, 2]
            names = gen_names(sum(layers))
            idx = 0
            layers_nodes = []
            for i, cnt in enumerate(layers):
                y = pad_y + i * ((h - 2 * pad_y) / (len(layers) - 1))
                step = (w - 2 * pad_x) / max(1, cnt - 1)
                layer = []
                for j in range(cnt):
                    g.add_node(names[idx], x=pad_x + j * step, y=y)
                    layer.append(names[idx])
                    idx += 1
                layers_nodes.append(layer)
            for i in range(len(layers_nodes) - 1):
                for u in layers_nodes[i]:
                    for v in layers_nodes[i+1]: 
                        g.add_edge(u, v, random.randint(1, 20), directed)

        elif "Cycle" in t:
            names = gen_names(8)
            cx, cy, R = w * 0.45, h * 0.5, min(w, h) * 0.36
            for i, n in enumerate(names):
                ang = 2 * math.pi * i / len(names)
                g.add_node(n, x=cx + R * math.cos(ang), y=cy + R * math.sin(ang))
            for i in range(len(names)):
                g.add_edge(names[i], names[(i + 1) % len(names)], random.randint(1, 20), directed)

        elif "Complete" in t:
            names = gen_names(6)
            cx, cy, R = w * 0.45, h * 0.5, min(w, h) * 0.36
            for i, n in enumerate(names):
                ang = 2 * math.pi * i / len(names)
                g.add_node(n, x=cx + R * math.cos(ang), y=cy + R * math.sin(ang))
            for i in range(len(names)):
                for j in range(i + 1, len(names)):
                    g.add_edge(names[i], names[j], random.randint(1, 20), directed)
                    if directed: g.add_edge(names[j], names[i], random.randint(1, 20), directed)

        elif "Binary" in t:
            names = gen_names(15)
            for lv in range(4):
                y = pad_y + lv * ((h - 2 * pad_y) / 3)
                count = 2 ** lv
                step = (w - 2 * pad_x) / max(1, count - 1)
                start_idx = 2**lv - 1
                for i in range(count):
                    idx = start_idx + i
                    if idx >= len(names): break
                    g.add_node(names[idx], x=pad_x + i * step, y=y)
                    if idx > 0: g.add_edge(names[(idx - 1) // 2], names[idx], random.randint(1, 20), directed)

        elif "Bipartite" in t:
            n_left, n_right = 5, 5
            all_names = gen_names(n_left + n_right)
            left = all_names[:n_left]
            right = all_names[n_left:]
            lx, rx = w * 0.2, w * 0.8
            for i, n in enumerate(left):
                y_pos = pad_y + i * ((h - 2 * pad_y) / (n_left - 1))
                g.add_node(n, x=lx, y=y_pos)
            for i, n in enumerate(right):
                y_pos = pad_y + i * ((h - 2 * pad_y) / (n_right - 1))
                g.add_node(n, x=rx, y=y_pos)

            connected_right_nodes = set()
            for u in left:
                v = random.choice(right)
                g.add_edge(u, v, random.randint(1, 20), directed)
                connected_right_nodes.add(v)
            for v in right:
                if v not in connected_right_nodes:
                    u = random.choice(left)
                    g.add_edge(u, v, random.randint(1, 20), directed)
            
            # Thêm ngẫu nhiên vài cạnh
            existing_edges = set((u, v) for u, v, w, d in g.edges)
            extra = 3
            count = 0
            while extra > 0 and count < 20:
                u = random.choice(left)
                v = random.choice(right)
                if (u, v) not in existing_edges:
                    g.add_edge(u, v, random.randint(1, 20), directed)
                    existing_edges.add((u, v))
                    extra -= 1
                count += 1

        else: # Random
            names = gen_names(10)
            for n in names:
                g.add_node(n, x=random.randint(pad_x, int(w-pad_x)), y=random.randint(pad_y, int(h-pad_y)))
            for i in range(len(names) - 1):
                g.add_edge(names[i], names[i+1], random.randint(1, 20), directed)
            for _ in range(8):
                u, v = random.sample(names, 2)
                g.add_edge(u, v, random.randint(1, 20), directed)

        g.redraw()
        self.master.log_panel.write(f"Tạo đồ thị mẫu: {t} | {'Có hướng' if directed else 'Vô hướng'}")