def graph_coloring(graph):

    vertices = list(graph.adj.keys())

    # Sắp xếp đỉnh theo số cạnh giảm dần (Heuristic Welsh–Powell)
    vertices.sort(key=lambda v: len(graph.adj[v]), reverse=True)

    color_map = {}
    color_used = 0

    for v in vertices:
        forbidden = set()

        # kiểm tra màu hàng xóm
        for neighbor, w in graph.adj[v]:
            if neighbor in color_map:
                forbidden.add(color_map[neighbor])

        # tìm màu nhỏ nhất chưa dùng
        color = 0
        while color in forbidden:
            color += 1

        color_map[v] = color
        color_used = max(color_used, color + 1)

    return color_map, color_used
