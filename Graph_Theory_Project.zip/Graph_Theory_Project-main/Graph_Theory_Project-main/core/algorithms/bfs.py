from collections import deque

def bfs(graph, start):
    
    if start not in graph.adj:
        return []

    visited = set([start])
    queue = deque([start])
    order = []

    while queue:
        u = queue.popleft()
        order.append(u)

        for v, w in graph.adj[u]:
            if v not in visited:
                visited.add(v)
                queue.append(v)

    return order
