import heapq
import math

def dijkstra(graph, start):
    """
    Dijkstra for directed/undirected LocalGraph.
    - Removes effect of duplicate edges.
    - Good for multigraph (parallel edges).
    Returns: dist, prev
    """

    if start not in graph.adj:
        return {}, {}

    # ====== INITIALIZATION ======
    dist = {v: math.inf for v in graph.adj}
    prev = {v: None for v in graph.adj}
    dist[start] = 0

    pq = [(0, start)]
    visited = set()

    # ====== MAIN LOOP ======
    while pq:
        d, u = heapq.heappop(pq)

        # If we've already finalized u → skip
        if u in visited:
            continue

        visited.add(u)

        # Relax neighbors
        for v, w in graph.adj[u]:

            # Ignore edges leading to visited nodes (optimization)
            if v in visited:
                continue

            newcost = dist[u] + w
            if newcost < dist[v]:
                dist[v] = newcost
                prev[v] = u
                heapq.heappush(pq, (newcost, v))

    return dist, prev


def reconstruct_path(prev, start, end):
    """
    Rebuild a shortest path from start to end using prev[].
    """
    if end not in prev:
        return None

    path = []
    cur = end
    while cur is not None:
        path.append(cur)
        if cur == start:
            break
        cur = prev[cur]

    path.reverse()

    return path if path[0] == start else None
