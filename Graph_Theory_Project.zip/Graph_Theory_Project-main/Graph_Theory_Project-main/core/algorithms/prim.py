import heapq

def prim(graph, start=None):
    """
    Corrected Prim’s Algorithm for UNDIRECTED LocalGraph
    - Removes duplicated edges (u→v and v→u)
    - Supports multigraph
    """

    if not graph.adj:
        return []

    # Use any vertex as start if not provided
    if start is None:
        start = next(iter(graph.adj))

    visited = set()
    mst = []
    pq = []

    def add_edges(u):
        """Push unique edges (u, v, w) to priority queue."""
        visited.add(u)
        
        for v, w in graph.adj[u]:
            # Avoid pushing reversed duplicate edges
            if v not in visited:
                heapq.heappush(pq, (w, u, v))

    # Start from initial vertex
    add_edges(start)

    while pq:
        w, u, v = heapq.heappop(pq)

        # Skip if v already in tree
        if v in visited:
            continue

        # Accept edge
        mst.append((u, v, w))
        add_edges(v)

    return mst
