def hamilton_path(graph, start, end):
    """
    Hamilton path from start to end.
    Returns a path list or None.
    """
    if start not in graph.adj or end not in graph.adj:
        return None

    nodes = list(graph.adj.keys())
    visited = set([start])
    path = [start]

    def backtrack(u):
        # If full length and we reach END
        if len(path) == len(nodes):
            return u == end

        for v, w in graph.adj[u]:
            if v not in visited:
                visited.add(v)
                path.append(v)
                if backtrack(v):
                    return True
                visited.remove(v)
                path.pop()

        return False

    if backtrack(start):
        return path
    return None


def hamilton_cycle(graph):
    """
    Hamilton cycle (start anywhere).
    Returns a cycle list or None.
    """
    nodes = list(graph.adj.keys())
    if not nodes:
        return None

    start = nodes[0]
    visited = set([start])
    path = [start]

    def backtrack(u):
        # Full length: check if last connects to start
        if len(path) == len(nodes):
            # Check if can return to start
            return any(v == start for v, w in graph.adj[u])

        for v, w in graph.adj[u]:
            if v not in visited:
                visited.add(v)
                path.append(v)
                if backtrack(v):
                    return True
                visited.remove(v)
                path.pop()

        return False

    if backtrack(start):
        path.append(start)   # close the cycle
        return path
    return None
