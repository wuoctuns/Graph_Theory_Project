import math

def bellman_ford(graph, start):
    """
    Bellman–Ford for directed/undirected LocalGraph.
    Returns:
        dist: dict
        prev: dict
        negative_cycle: bool
    """

    # If start not in graph → no solution
    if start not in graph.adj:
        return {}, {}, False

    # ====== BUILD EDGE LIST (UNDIRECTED SAFE) ======
    edges = []
    for u in graph.adj:
        for v, w in graph.adj[u]:
            edges.append((u, v, w))
            # Không remove duplicate vì multigraph cần giữ nguyên
            # Bellman-Ford chịu được duplicate edges

    # ====== INIT ======
    dist = {v: math.inf for v in graph.adj}
    prev = {v: None for v in graph.adj}

    dist[start] = 0

    V = len(graph.adj)

    # ====== RELAX EDGES V-1 TIMES ======
    for _ in range(V - 1):
        updated = False
        for u, v, w in edges:

            # Relax condition
            if dist[u] != math.inf and dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                prev[v] = u
                updated = True

        if not updated:
            break

    # ====== CHECK NEGATIVE CYCLE ======
    negative_cycle = False
    for u, v, w in edges:
        if dist[u] != math.inf and dist[u] + w < dist[v]:
            negative_cycle = True
            break

    return dist, prev, negative_cycle


def reconstruct_path(prev, start, end):
    """
    Rebuild path using prev[] after Bellman-Ford.
    Same style as Dijkstra's reconstruct.
    """
    if end not in prev:
        return None

    path = []
    cur = end

    while cur is not None:
        path.append(cur)
        if cur == start:
            break
        cur = prev[cur]

    path.reverse()

    return path if path[0] == start else None
