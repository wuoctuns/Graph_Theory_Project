from gremlin_python.driver.client import Client
from datetime import datetime


class JanusGraphService:
    def __init__(self, url="ws://localhost:8182/gremlin"):
        self.url = url
        self.client = None

    # ============================================================
    # CONNECT
    # ============================================================
    def connect(self):
        if not self.client:
            self.client = Client(self.url, "g")

    def close(self):
        if self.client:
            self.client.close()
            self.client = None

    # ============================================================
    # LIST GRAPH META
    # ============================================================
    def list_graphs(self):
        self.connect()
        return self.client.submit("""
            g.V().hasLabel('graph_meta')
            .project(
                'graph_id','name','description',
                'directed','node_count','edge_count','saved_at'
            )
            .by('graph_id')
            .by('name')
            .by('description')
            .by('directed')
            .by('node_count')
            .by('edge_count')
            .by('saved_at')
        """).all().result()


    # ============================================================
    # LOAD GRAPH (NODE + EDGE + XY)
    # ============================================================
    def load_graph(self, graph_id):
        self.connect()

        nodes = self.client.submit("""
            g.V().hasLabel('node')
             .has('graph_id', gid)
             .project('name','x','y')
             .by('name')
             .by(values('x'))
             .by(values('y'))
        """, {"gid": graph_id}).all().result()

        edges = self.client.submit("""
            g.E().hasLabel('connects')
             .has('graph_id', gid)
             .project('u','v','w','directed')
             .by(outV().values('name'))
             .by(inV().values('name'))
             .by(values('weight'))
             .by(values('directed'))
        """, {"gid": graph_id}).all().result()

        return nodes, edges

    # ============================================================
    # UPLOAD GRAPH
    # ============================================================
    def upload_graph(self, graph_area, meta):
        self.connect()
        gid = meta["graph_id"]

        saved_at = meta.get(
            "saved_at_str",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )

        # ---------- META ----------
        self.client.submit(
            """
            g.addV('graph_meta')
            .property('graph_id', gid)
            .property('name', gname)
            .property('description', gdesc)
            .property('directed', directed)
            .property('node_count', ncount)
            .property('edge_count', ecount)
            .property('saved_at', saved_at)
            .iterate()
            """,
            {
                "gid": gid,
                "gname": meta.get("name", ""),
                "gdesc": str(meta.get("description", "")),
                "directed": bool(meta.get("directed", False)),
                "ncount": len(graph_area.nodes),
                "ecount": len(graph_area.edges),
                "saved_at": saved_at
            }
        ).all().result()

        # ---------- NODE ----------
        for name, d in graph_area.nodes.items():
            self.client.submit("""
                g.addV('node')
                 .property('name', n)
                 .property('x', x)
                 .property('y', y)
                 .property('graph_id', gid)
                 .iterate()
            """, {
                "n": name,
                "x": float(d["x"]),
                "y": float(d["y"]),
                "gid": gid
            }).all().result()

        # ---------- EDGE ----------
        for u, v, w, directed in graph_area.edges:
            self.client.submit("""
                g.V().hasLabel('node')
                 .has('name', u)
                 .has('graph_id', gid).as('a')
                 .V().hasLabel('node')
                 .has('name', v)
                 .has('graph_id', gid)
                 .addE('connects')
                 .from('a')
                 .property('weight', w)
                 .property('directed', directed)
                 .property('graph_id', gid)
                 .iterate()
            """, {
                "u": u,
                "v": v,
                "w": int(w),
                "directed": bool(directed),
                "gid": gid
            }).all().result()

    # ============================================================
    # DELETE GRAPH
    # ============================================================
    def delete_graph(self, graph_id):
        self.connect()

        # Xóa toàn bộ cạnh trước
        self.client.submit(
            "g.E().has('graph_id', gid).drop()",
            {"gid": graph_id}
        ).all().result()

        # Xóa toàn bộ đỉnh (node + graph_meta)
        self.client.submit(
            "g.V().has('graph_id', gid).drop()",
            {"gid": graph_id}
        ).all().result()