from gremlin_python.driver.client import Client

#Đổi 8182 thành 8183
client = Client("ws://localhost:8183/gremlin", "g")

print("Đang kết nối...")
try:
    # Lấy kết quả trả về
    result = client.submit("g.V().count()").all().result()
    print("✅ KẾT NỐI THÀNH CÔNG!")
    print("Số đỉnh trong JanusGraph:", result)
except Exception as e:
    print("❌ Lỗi:", e)
finally:
    client.close()