# Fleury Algorithm (Undirected Only)
# Supports: Euler Path + Euler Circuit + Multigraph + Self-loop

import copy

def fleury(graph):
    """
    Return Euler path or Euler circuit using Fleury algorithm.
    graph.adj must be undirected adjacency list: {u: [(v, w), ...]}
    """
    if graph.directed:
        return "❌ Euler chỉ áp dụng cho đồ thị vô hướng."

    adj = copy.deepcopy(graph.adj)

    # -------------------- DEGREE CHECK --------------------
    degree = {u: len(adj[u]) for u in adj}

    odd = [u for u in degree if degree[u] % 2 == 1]

    # Determine starting point
    if len(odd) == 0:
        # Euler circuit
        start = next(iter(adj))
    elif len(odd) == 2:
        # Euler trail
        start = odd[0]
    else:
        return "❌ Không tồn tại đường đi hoặc chu trình Euler."

    # -------------------- HELPER FUNCTIONS --------------------

    def remove_edge(u, v):
        """Remove ONE INSTANCE of edge u–v (correct for multigraph)."""
        for i, (x, w) in enumerate(adj[u]):
            if x == v:
                adj[u].pop(i)
                break
        for i, (x, w) in enumerate(adj[v]):
            if x == u:
                adj[v].pop(i)
                break

    def dfs_count(u, visited):
        visited.add(u)
        for v, w in adj[u]:
            if v not in visited:
                dfs_count(v, visited)

    def is_bridge(u, v):
        """
        An edge u–v is a bridge if removing it reduces connectivity.
        Must remove only ONE instance for multigraph correctness.
        """
        # Step 1: Count reachable vertices before removing
        visited_before = set()
        dfs_count(u, visited_before)

        # Step 2: Remove ONE instance of edge
        remove_edge(u, v)

        # Step 3: Count reachable vertices after removing
        visited_after = set()
        dfs_count(u, visited_after)

        # Step 4: Restore edge
        adj[u].append((v, 1))
        adj[v].append((u, 1))

        # Step 5: If connectivity reduced → it's a bridge
        return len(visited_after) < len(visited_before)

    # -------------------- MAIN FLEURY --------------------

    path = [start]
    current = start

    while True:
        if len(adj[current]) == 0:
            break  # no more edges → stop

        # Try all edges from current
        for v, w in list(adj[current]):
            # If only one edge left, must take it
            if len(adj[current]) == 1:
                remove_edge(current, v)
                current = v
                path.append(v)
                break

            # Otherwise avoid bridges
            if not is_bridge(current, v):
                remove_edge(current, v)
                current = v
                path.append(v)
                break

    return path
