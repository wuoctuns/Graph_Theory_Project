def dfs(graph, start):

    visited = set()
    order = []

    def visit(u):
        visited.add(u)
        order.append(u)
        for v, w in graph.adj.get(u, []):
            if v not in visited:
                visit(v)

    if start in graph.adj:
        visit(start)

    return order
