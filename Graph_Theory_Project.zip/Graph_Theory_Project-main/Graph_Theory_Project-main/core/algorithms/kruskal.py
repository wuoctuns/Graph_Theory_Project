def kruskal(graph):
    """
    Corrected Kruskal for UNDIRECTED LocalGraph
    - Removes duplicated edges u→v and v→u
    - Supports multigraph
    """

    parent = {}
    rank = {}

    # ========== Disjoint Set (Union-Find) Helpers ==========
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            if rank[ra] < rank[rb]:
                parent[ra] = rb
            elif rank[ra] > rank[rb]:
                parent[rb] = ra
            else:
                parent[rb] = ra
                rank[ra] += 1

    # Initialize DSU
    for v in graph.adj:
        parent[v] = v
        rank[v] = 0

    # ========== BUILD EDGE LIST (UNDIRECTED SAFE) ==========
    edges = set()   

    for u in graph.adj:
        for v, w in graph.adj[u]:
            if u <= v:
                edges.add((w, u, v))
            else:
                edges.add((w, v, u))

    edges = sorted(list(edges))

    # ========== KRUSKAL MAIN LOOP ==========
    mst = []

    for w, u, v in edges:
        if find(u) != find(v):
            union(u, v)
            mst.append((u, v, w))

    return mst
