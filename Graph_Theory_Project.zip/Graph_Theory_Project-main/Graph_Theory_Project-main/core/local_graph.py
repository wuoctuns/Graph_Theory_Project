class LocalGraph:
    def __init__(self, directed=False):
        self.directed = directed

        # danh sách đỉnh
        self.vertices = set()

        # danh sách cạnh: (u, v, w, directed)
        self.edges = []

        # adjacency: {u: [(v, w), ...]}
        self.adj = {}

    # ============================== VERTEX ==============================
    def add_vertex(self, v):
        if v not in self.vertices:
            self.vertices.add(v)
            self.adj[v] = []

    def remove_vertex(self, v):
        if v not in self.vertices:
            return

        self.vertices.remove(v)
        del self.adj[v]

        for u in self.adj:
            self.adj[u] = [(x, w) for (x, w) in self.adj[u] if x != v]

        self.edges = [(u, x, w, d)
                      for (u, x, w, d) in self.edges
                      if u != v and x != v]

    # ============================== EDGE ==============================
    def add_edge(self, u, v, w=1, directed=None):
        """
        directed:
          - None  → dùng self.directed (chuẩn mới)
          - True/False → tương thích code cũ
        """
        self.add_vertex(u)
        self.add_vertex(v)

        if directed is None:
            directed = self.directed

        self.adj[u].append((v, w))
        self.edges.append((u, v, w, directed))

        if not directed and u != v:
            self.adj[v].append((u, w))
            self.edges.append((v, u, w, directed))

    def remove_edge(self, u, v, directed=None):
        if directed is None:
            directed = self.directed

        if u in self.adj:
            self.adj[u] = [(x, w) for (x, w) in self.adj[u] if x != v]

        if not directed and v in self.adj:
            self.adj[v] = [(x, w) for (x, w) in self.adj[v] if x != u]

        self.edges = [
            (a, b, w, d)
            for (a, b, w, d) in self.edges
            if not ((a == u and b == v) or (not directed and a == v and b == u))
        ]

    # ============================== UTILITIES ==============================
    def neighbors(self, u):
        return self.adj.get(u, [])

    def clear(self):
        self.vertices.clear()
        self.edges.clear()
        self.adj.clear()

    def edge_count(self, u, v):
        return sum(1 for (a, b, w, d) in self.edges if a == u and b == v)
